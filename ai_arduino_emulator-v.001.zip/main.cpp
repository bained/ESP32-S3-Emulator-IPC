#include "include/Arduino.h"
#include "Runtime/Runtime.h"
#include "GPIO/GPIOManager.h"
#include "HAL/WindowsPipeSensor.h"

// Standard Blink Sketch Configuration
const int ledPin = LED_BUILTIN;
const int sensorPin = 4; // Use pin 4 as our external sensor input pin

// Instantiate the Windows Named Pipe Sensor
static arduino::hal::WindowsPipeSensor pipeSensor("\\\\.\\pipe\\SensorPipe");

// ==========================================
// User Application Code (Standard Sketch)
// ==========================================

void setup() {
    // Initialize serial communication
    Serial.begin(115200);
    Serial.println("==========================================");
    Serial.println("   ESP32-S3 Windows Emulator - Blink/IPC  ");
    Serial.println("==========================================");

    // Initialize pins
    pinMode(ledPin, OUTPUT);
    pinMode(sensorPin, INPUT);

    // Register the WindowsPipeSensor with the GPIOManager for pin 4
    arduino::GPIOManager::getInstance().registerExternalSensor(sensorPin, &pipeSensor);

    Serial.printf("[Setup] Initialized LED on pin %d as OUTPUT\n", ledPin);
    Serial.printf("[Setup] Initialized Sensor on pin %d as INPUT (Registered with IPC Named Pipe)\n", sensorPin);
}

void loop() {
    // Read the dynamically updated sensor value from the IPC pipe
    int sensorValue = analogRead(sensorPin);
    Serial.printf("[Loop @ %lu ms] Read External Sensor: %d\n", millis(), sensorValue);

    // Turn the LED on (HIGH is the voltage level)
    // This will trigger digitalWrite, which sends a command ("SET_HIGH") back to the sensor proxy
    digitalWrite(ledPin, HIGH);
    Serial.printf("[Loop @ %lu ms] LED is ON (pin %d -> HIGH)\n", millis(), ledPin);
    delay(1000); // wait for a second

    // Turn the LED off (LOW)
    // This will trigger digitalWrite, which sends a command ("SET_LOW") back to the sensor proxy
    digitalWrite(ledPin, LOW);
    Serial.printf("[Loop @ %lu ms] LED is OFF (pin %d -> LOW)\n", millis(), ledPin);
    delay(1000); // wait for a second
}

// ==========================================
// Emulator Entry Point
// ==========================================

int main() {
    // Initialize the Arduino Runtime instance
    arduino::Runtime emulatorRuntime;

    // Run the Arduino lifecycle (setup once, loop infinitely)
    emulatorRuntime.run();

    return 0;
}
