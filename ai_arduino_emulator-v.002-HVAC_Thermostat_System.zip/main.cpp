#include "include/Arduino.h"
#include "Runtime/Runtime.h"
#include "GPIO/GPIOManager.h"
#include "HAL/WindowsPipeSensor.h"
#include "Logic/ThermostatController.h"

// Standard configuration
const int ledPin = LED_BUILTIN;
const int sensorPin = 4; // Analog temperature sensor pin

// Instantiate our HAL sensor pipe client
static arduino::hal::WindowsPipeSensor pipeSensor("\\\\.\\pipe\\SensorPipe");

// Instantiate our Decoupled HVAC Controller with 0.5°C hysteresis
static arduino::ThermostatController thermostat(&pipeSensor, 0.5f);

// ==========================================
// User Application Code (Standard Sketch)
// ==========================================

void setup() {
    // Initialize serial communication
    Serial.begin(115200);
    Serial.println("==========================================");
    Serial.println("   ESP32-S3 Windows Thermostat Emulator   ");
    Serial.println("==========================================");

    // Initialize LED and Sensor pins
    pinMode(ledPin, OUTPUT);
    pinMode(sensorPin, INPUT);

    // Initialize cooling stage indication pins
    pinMode(10, OUTPUT); // Low Stage LED
    pinMode(11, OUTPUT); // Medium Stage LED
    pinMode(12, OUTPUT); // High Stage LED
    pinMode(13, OUTPUT); // Max Stage LED

    // Link the named pipe IPC sensor to Pin 4
    arduino::GPIOManager::getInstance().registerExternalSensor(sensorPin, &pipeSensor);

    Serial.printf("[Setup] Registered named pipe sensor to pin %d\n", sensorPin);
    Serial.printf("[Setup] Initialized Thermostat Controller (Hysteresis: 0.5 C)\n");
}

void loop() {
    // 1. Perform thermostat control step (updates readings, transitions stages with hysteresis, controls output pins 10-13)
    int stage = thermostat.update();
    float currentTemp = thermostat.getCurrentTemperature();

    // 2. Log status via our emulated Serial console
    Serial.printf("[HVAC Status] Temp: %6.2f C | Cooling Stage: %d [ %-6s ]\n",
                  currentTemp,
                  stage,
                  (stage == 0 ? "OFF" :
                   stage == 1 ? "LOW" :
                   stage == 2 ? "MEDIUM" :
                   stage == 3 ? "HIGH" : "MAX"));

    // 3. Blink built-in heartbeat LED to indicate the emulator is fully active
    digitalWrite(ledPin, HIGH);
    delay(500);
    digitalWrite(ledPin, LOW);
    delay(500);
}

// ==========================================
// Emulator Entry Point
// ==========================================

int main() {
    // Initialize and boot the emulator run loop
    arduino::Runtime emulatorRuntime;
    emulatorRuntime.run();

    return 0;
}
