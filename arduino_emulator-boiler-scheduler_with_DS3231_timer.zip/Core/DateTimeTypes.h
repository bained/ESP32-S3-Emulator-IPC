#pragma once

#include <cstdint>
#include <cstdio>
#include <string>

// ==========================================
// Calendar date/time primitives
// ==========================================
// Pure, platform independent Howard Hinnant style civil calendar helpers.
// No Windows API, no HAL dependency: safe to use from Core, Logic and HAL.

namespace arduino {
namespace datetime {

struct DateTime {
    int year;         // e.g. 2026
    uint8_t month;    // 1 - 12
    uint8_t day;      // 1 - 31
    uint8_t hour;     // 0 - 23
    uint8_t minute;   // 0 - 59
    uint8_t second;   // 0 - 59
};

// Days since 1970-01-01 for a civil date (proleptic Gregorian calendar).
constexpr int64_t daysFromCivil(int y, unsigned m, unsigned d) {
    y -= (m <= 2) ? 1 : 0;
    const int era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = static_cast<unsigned>(y - era * 400);
    const unsigned doy = (153 * (m > 2 ? m - 3 : m + 9) + 2) / 5 + d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return static_cast<int64_t>(era) * 146097 + static_cast<int64_t>(doe) - 719468;
}

// Inverse of daysFromCivil().
constexpr void civilFromDays(int64_t z, int& y, unsigned& m, unsigned& d) {
    z += 719468;
    const int64_t era = (z >= 0 ? z : z - 146096) / 146097;
    const unsigned doe = static_cast<unsigned>(z - era * 146097);
    const unsigned yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    const unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    const unsigned mp = (5 * doy + 2) / 153;
    d = doy - (153 * mp + 2) / 5 + 1;
    m = (mp < 10) ? mp + 3 : mp - 9;
    y = static_cast<int>(yoe + static_cast<unsigned>(era) * 400) + ((m <= 2) ? 1 : 0);
}

constexpr int64_t toEpoch(const DateTime& dt) {
    return daysFromCivil(dt.year, dt.month, dt.day) * 86400LL +
           static_cast<int64_t>(dt.hour) * 3600LL +
           static_cast<int64_t>(dt.minute) * 60LL +
           static_cast<int64_t>(dt.second);
}

constexpr DateTime fromEpoch(int64_t epoch) {
    int64_t dayIndex = epoch / 86400LL;
    int64_t secOfDay = epoch % 86400LL;
    if (secOfDay < 0) { // Guard against pre-1970 values
        secOfDay += 86400LL;
        --dayIndex;
    }
    int y = 0;
    unsigned m = 1;
    unsigned d = 1;
    civilFromDays(dayIndex, y, m, d);
    return DateTime{y,
                    static_cast<uint8_t>(m),
                    static_cast<uint8_t>(d),
                    static_cast<uint8_t>(secOfDay / 3600),
                    static_cast<uint8_t>((secOfDay % 3600) / 60),
                    static_cast<uint8_t>(secOfDay % 60)};
}

// Seconds elapsed since local midnight (0 - 86399).
constexpr uint32_t secondOfDay(const DateTime& dt) {
    return static_cast<uint32_t>(dt.hour) * 3600u +
           static_cast<uint32_t>(dt.minute) * 60u +
           static_cast<uint32_t>(dt.second);
}

// 1 = Monday ... 7 = Sunday (ISO-8601, same convention the DS3231 uses).
constexpr uint8_t isoWeekday(const DateTime& dt) {
    const int64_t days = daysFromCivil(dt.year, dt.month, dt.day);
    int dow = static_cast<int>((days + 3) % 7); // 1970-01-01 was a Thursday
    if (dow < 0) dow += 7;
    return static_cast<uint8_t>(dow + 1);
}

constexpr bool isLeapYear(int y) {
    return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
}

constexpr uint8_t daysInMonth(int y, uint8_t m) {
    const uint8_t days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (m < 1 || m > 12) return 31;
    if (m == 2 && isLeapYear(y)) return 29;
    return days[m - 1];
}

// Clamp an arbitrary date/time into a valid representation (DS3231 range 2000-2099).
inline DateTime normalize(DateTime dt) {
    if (dt.year < 2000) dt.year = 2000;
    if (dt.year > 2099) dt.year = 2099;
    if (dt.month < 1) dt.month = 1;
    if (dt.month > 12) dt.month = 12;
    const uint8_t maxDay = daysInMonth(dt.year, dt.month);
    if (dt.day < 1) dt.day = 1;
    if (dt.day > maxDay) dt.day = maxDay;
    if (dt.hour > 23) dt.hour = 23;
    if (dt.minute > 59) dt.minute = 59;
    if (dt.second > 59) dt.second = 59;
    return dt;
}

// Shift by a number of days keeping the time of day (month/year aware).
inline DateTime addDays(const DateTime& dt, int32_t days) {
    return fromEpoch(toEpoch(dt) + static_cast<int64_t>(days) * 86400LL);
}

// ISO-8601 text form: "2026-10-31 06:30:00"
inline std::string format(const DateTime& dt) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%04d-%02u-%02u %02u:%02u:%02u",
                  dt.year, static_cast<unsigned>(dt.month), static_cast<unsigned>(dt.day),
                  static_cast<unsigned>(dt.hour), static_cast<unsigned>(dt.minute),
                  static_cast<unsigned>(dt.second));
    return std::string(buf);
}

// Compact "HH:MM" text form, handy for schedule logging.
inline std::string formatHHMM(uint32_t secondsOfDay) {
    char buf[8];
    std::snprintf(buf, sizeof(buf), "%02u:%02u",
                  static_cast<unsigned>((secondsOfDay / 3600) % 24),
                  static_cast<unsigned>((secondsOfDay % 3600) / 60));
    return std::string(buf);
}

// Strict "YYYY-MM-DD HH:MM:SS" parser (a missing seconds field means 00).
inline bool parseTimestamp(const std::string& text, DateTime& out) {
    int y = 2000, mo = 1, d = 1, h = 0, mi = 0, s = 0;
    const int fields = std::sscanf(text.c_str(), "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &s);
    if (fields < 5) return false;
    out = normalize(DateTime{y, static_cast<uint8_t>(mo), static_cast<uint8_t>(d),
                             static_cast<uint8_t>(h), static_cast<uint8_t>(mi),
                             static_cast<uint8_t>(s)});
    return true;
}

// Strict "HH:MM" / "HH:MM:SS" parser used for schedule windows.
inline bool parseClock(const std::string& text, uint32_t& secondsOfDay) {
    int h = -1, mi = -1, s = 0;
    if (std::sscanf(text.c_str(), "%d:%d:%d", &h, &mi, &s) < 2) return false;
    if (h < 0 || h > 23 || mi < 0 || mi > 59 || s < 0 || s > 59) return false;
    secondsOfDay = static_cast<uint32_t>(h) * 3600u + static_cast<uint32_t>(mi) * 60u +
                   static_cast<uint32_t>(s);
    return true;
}

} // namespace datetime
} // namespace arduino
