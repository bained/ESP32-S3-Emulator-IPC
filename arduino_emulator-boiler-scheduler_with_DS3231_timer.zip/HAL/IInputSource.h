#pragma once

#include <string>

namespace arduino {
namespace hal {

// Non-blocking source of debug/console input for the sketch.
// Keeps keyboard handling (a Windows console API concern) behind the HAL so the
// sketch stays free of platform code, exactly like IConsole does for output.
class IInputSource {
public:
    virtual ~IInputSource() = default;

    // True when at least one key is waiting to be consumed.
    virtual bool available() = 0;

    // Returns the next key as a character code, or -1 when the queue is empty.
    virtual int read() = 0;

    // Last error/event message queued by the input source (empty when none).
    virtual std::string takeMessage() { return std::string(); }
};

} // namespace hal
} // namespace arduino
