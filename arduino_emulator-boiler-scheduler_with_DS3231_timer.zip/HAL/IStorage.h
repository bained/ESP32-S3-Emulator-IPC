#pragma once

#include <string>

namespace arduino {
namespace hal {

// Key/value persistent configuration store.
// Keeps the Logic layer free of any file system / platform dependency:
// the Windows build reads a plain ".ini" file, while the ESP32-S3 target can
// provide an SPIFFS / LittleFS / Preferences backed implementation.
class IStorage {
public:
    virtual ~IStorage() = default;

    // Key/value access. Values are always stored as text.
    virtual bool getString(const std::string& key, std::string& value) const = 0;
    virtual bool setString(const std::string& key, const std::string& value) = 0;

    virtual bool getInt(const std::string& key, long& value) const = 0;
    virtual bool setInt(const std::string& key, long value) = 0;

    virtual bool getBool(const std::string& key, bool& value) const = 0;
    virtual bool setBool(const std::string& key, bool value) = 0;

    // Removes a single key from the in-memory representation.
    virtual bool remove(const std::string& key) = 0;

    // Reloads the backing file into memory (used for live configuration reload).
    virtual bool reload() = 0;

    // Flushes the in-memory representation back to the backing file.
    virtual bool commit() = 0;

    // Human readable name/path of the backing store (for diagnostics only).
    virtual const std::string& location() const = 0;
};

} // namespace hal
} // namespace arduino
