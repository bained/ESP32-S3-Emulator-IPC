#define NOMINMAX
#include "WindowsConsoleInput.h"

#include <windows.h>
#include <cctype>

namespace arduino {
namespace hal {

namespace {

// Keys the emulator console reacts to. Everything else is ignored so that the
// terminal scroll/selection or a stray typing cannot disturb the simulation.
constexpr int KEY_FAST_FORWARD = ']';
constexpr int KEY_FAST_REWIND = '[';
constexpr int KEY_BOOST = 'b';
constexpr int KEY_RELOAD = 'r';
constexpr int KEY_CLEAR = 'c';
constexpr int KEY_HELP = 'h';
constexpr int KEY_ESCAPE = 27;

WindowsConsoleInput* g_activeInput = nullptr;

// Console control handler: Windows invokes this on Ctrl+C / Ctrl+Break / close.
// Returning TRUE tells Windows the event was handled, so the process keeps
// running and the sketch can perform an orderly shutdown on the next loop().
BOOL WINAPI consoleControlHandler(DWORD) {
    if (g_activeInput != nullptr) {
        g_activeInput->pushKey(KEY_ESCAPE);
    }
    return TRUE;
}

} // namespace

WindowsConsoleInput::WindowsConsoleInput() : m_attached(false), m_previousProcedure(nullptr) {
    // Attach to the windowing console only; a redirected/piped stdout (e.g. CI)
    // has no keyboard attached and simply keeps the queue empty.
    if (SetConsoleCtrlHandler(reinterpret_cast<PHANDLER_ROUTINE>(consoleControlHandler), TRUE)) {
        m_attached = true;
    }
    g_activeInput = this;
}

WindowsConsoleInput::~WindowsConsoleInput() {
    if (m_attached) {
        SetConsoleCtrlHandler(reinterpret_cast<PHANDLER_ROUTINE>(consoleControlHandler), FALSE);
    }
    if (g_activeInput == this) {
        g_activeInput = nullptr;
    }
}

bool WindowsConsoleInput::available() {
    // Poll the console keyboard buffer: Windowed consoles expose their input
    // through ReadConsoleInput, while redirected stdin reports 0 events.
    HANDLE input = GetStdHandle(STD_INPUT_HANDLE);
    if (input == INVALID_HANDLE_VALUE || input == nullptr) {
        return !m_keys.empty();
    }

    DWORD pending = 0;
    if (!GetNumberOfConsoleInputEvents(input, &pending) || pending == 0) {
        return !m_keys.empty();
    }

    bool polledSomething = false;
    INPUT_RECORD record;
    DWORD read = 0;
    while (pending-- > 0) {
        if (!ReadConsoleInputA(input, &record, 1, &read) || read == 0) {
            break;
        }
        if (record.EventType != KEY_EVENT || record.Event.KeyEvent.bKeyDown == 0) {
            continue;
        }
        const char character = record.Event.KeyEvent.uChar.AsciiChar;
        if (character == 0) {
            continue; // Arrow / function keys carry no ASCII character
        }
        m_keys.push_back(static_cast<unsigned char>(character));
        polledSomething = true;
    }
    (void)polledSomething;
    return !m_keys.empty();
}

int WindowsConsoleInput::read() {
    if (m_keys.empty()) {
        return -1;
    }
    const int key = m_keys.front();
    m_keys.pop_front();
    return key;
}

std::string WindowsConsoleInput::takeMessage() {
    if (m_messages.empty()) {
        return std::string();
    }
    const std::string message = m_messages.front();
    m_messages.pop_front();
    return message;
}

void WindowsConsoleInput::pushKey(int key) {
    if (std::isprint(key) != 0 || key == KEY_ESCAPE) {
        m_keys.push_back(key);
    }
}

} // namespace hal
} // namespace arduino
