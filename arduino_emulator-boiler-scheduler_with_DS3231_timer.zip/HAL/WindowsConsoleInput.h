#pragma once

#include "IInputSource.h"
#include <deque>

namespace arduino {
namespace hal {

// Windows implementation of IInputSource.
//
// The emulator console is a "press a key" console: the sketch cannot read from
// the keyboard directly (the console handles the key events), so the Windows
// console procedure installed by this class captures the keys and pushes them
// into a small queue which the sketch polls from loop().
//
// Keys that carry an on-screen report (sent by the sketch after each action)
// are handled as a "debug command" and surfaced through takeMessage().
class WindowsConsoleInput : public IInputSource {
public:
    WindowsConsoleInput();
    ~WindowsConsoleInput() override;

    bool available() override;
    int read() override;
    std::string takeMessage() override;

    // True when the console procedure was installed successfully.
    bool isAttached() const { return m_attached; }

    // Key that the console procedure stores for shift/step commands.
    // (Reported back to the sketch so it can apply the action.)
    void pushKey(int key);

private:
    std::deque<int> m_keys;
    std::deque<std::string> m_messages;
    bool m_attached;
    void* m_previousProcedure; // Saved WNDPROC / PHANDLER_ROUTINE (opaque)
};

} // namespace hal
} // namespace arduino
