#pragma once

#include "IStorage.h"
#include <map>
#include <string>
#include <vector>

namespace arduino {
namespace hal {

// Plain-text ".ini" backed implementation of IStorage.
//
// File format (deliberately simple so it can also be parsed by the ESP32 target):
//
//   ; comment
//   # comment
//   [section]
//   key=value
//
// Keys are addressed as "section.key". A key that appears before the first
// section header lives in the implicit "" (root) section and is addressed by
// its bare name. All Windows file system calls are confined to this class.
class WindowsIniFileStorage : public IStorage {
public:
    explicit WindowsIniFileStorage(const std::string& filePath);

    bool getString(const std::string& key, std::string& value) const override;
    bool setString(const std::string& key, const std::string& value) override;

    bool getInt(const std::string& key, long& value) const override;
    bool setInt(const std::string& key, long value) override;

    bool getBool(const std::string& key, bool& value) const override;
    bool setBool(const std::string& key, bool value) override;

    bool remove(const std::string& key) override;

    bool reload() override;
    bool commit() override;

    const std::string& location() const override { return m_filePath; }

    // True when the backing file existed and was parsed successfully.
    bool isLoaded() const { return m_loaded; }
    // Number of key/value pairs currently held in memory.
    size_t size() const { return m_entries.size(); }

private:
    struct Entry {
        std::string section;
        std::string key;
        std::string value;
    };

    std::string m_filePath;
    std::map<std::string, std::string> m_entries; // "section.key" -> value
    bool m_loaded;

    // Ensures the directory of the config file exists (Windows only).
    bool ensureParentDirectory() const;

    // Line-edits the current file into `output`, removing written keys from
    // `pending` so that commit() only appends genuinely new entries.
    bool editExistingFile(std::vector<std::string>& output,
                          std::map<std::string, std::string>& pending) const;

    static std::string trim(const std::string& text);
    static bool splitKey(const std::string& fullKey, std::string& section, std::string& key);
    static bool parseBool(const std::string& text, bool& value);
};

} // namespace hal
} // namespace arduino
