#define NOMINMAX
#include "WindowsIniFileStorage.h"

#include <windows.h>
#include <direct.h>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <fstream>
#include <vector>

namespace arduino {
namespace hal {

namespace {

// Creates every missing directory of the supplied path.
bool createDirectories(const std::string& directory) {
    if (directory.empty() || directory == "." || directory == "\\" || directory == "/") {
        return true;
    }
    if (GetFileAttributesA(directory.c_str()) != INVALID_FILE_ATTRIBUTES) {
        return true;
    }
    // Create the parent first, then the leaf.
    const size_t slash = directory.find_last_of("\\/");
    if (slash != std::string::npos && slash > 2) {
        if (!createDirectories(directory.substr(0, slash))) {
            return false;
        }
    }
    return _mkdir(directory.c_str()) == 0 ||
           GetFileAttributesA(directory.c_str()) != INVALID_FILE_ATTRIBUTES;
}

std::string toLower(std::string text) {
    std::transform(text.begin(), text.end(), text.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return text;
}

} // namespace

WindowsIniFileStorage::WindowsIniFileStorage(const std::string& filePath)
    : m_filePath(filePath), m_loaded(false) {
    reload();
}

std::string WindowsIniFileStorage::trim(const std::string& text) {
    const size_t first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
        return std::string();
    }
    const size_t last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

bool WindowsIniFileStorage::splitKey(const std::string& fullKey, std::string& section,
                                     std::string& key) {
    const size_t dot = fullKey.find('.');
    if (dot == std::string::npos) {
        section.clear();
        key = toLower(trim(fullKey));
        return !key.empty();
    }
    section = toLower(trim(fullKey.substr(0, dot)));
    key = toLower(trim(fullKey.substr(dot + 1)));
    return !section.empty() && !key.empty();
}

bool WindowsIniFileStorage::parseBool(const std::string& text, bool& value) {
    const std::string v = toLower(trim(text));
    if (v == "1" || v == "true" || v == "yes" || v == "on") {
        value = true;
        return true;
    }
    if (v == "0" || v == "false" || v == "no" || v == "off") {
        value = false;
        return true;
    }
    return false;
}

bool WindowsIniFileStorage::ensureParentDirectory() const {
    const size_t slash = m_filePath.find_last_of("\\/");
    if (slash == std::string::npos) {
        return true;
    }
    return createDirectories(m_filePath.substr(0, slash));
}

bool WindowsIniFileStorage::reload() {
    m_entries.clear();
    m_loaded = false;

    std::ifstream file(m_filePath);
    if (!file.is_open()) {
        return false;
    }

    std::string currentSection;
    std::string line;
    while (std::getline(file, line)) {
        const std::string trimmed = trim(line);
        if (trimmed.empty() || trimmed[0] == ';' || trimmed[0] == '#') {
            continue; // Comment or blank line
        }
        if (trimmed.front() == '[' && trimmed.back() == ']') {
            currentSection = toLower(trim(trimmed.substr(1, trimmed.size() - 2)));
            continue;
        }
        const size_t equals = trimmed.find('=');
        if (equals == std::string::npos) {
            continue; // Malformed line: ignore it instead of aborting the whole load
        }
        const std::string key = toLower(trim(trimmed.substr(0, equals)));
        std::string value = trim(trimmed.substr(equals + 1));
        if (key.empty()) {
            continue;
        }
        const std::string fullKey = currentSection.empty() ? key : currentSection + "." + key;
        m_entries[fullKey] = value;
    }

    m_loaded = true;
    return true;
}

bool WindowsIniFileStorage::commit() {
    if (!ensureParentDirectory()) {
        return false;
    }

    // Keep the author's comments/documentation: the existing file is line-edited
    // in place (known keys get the new value, unknown lines are copied verbatim)
    // and only genuinely new keys are appended to their section.
    std::map<std::string, std::string> pending = m_entries; // Keys not yet written
    std::vector<std::string> output;
    if (!editExistingFile(output, pending)) {
        output.clear();
    }

    // Append whatever was not present in the original file, grouped by section.
    std::string currentSection = output.empty() ? "\x01" : "";
    for (const auto& entry : pending) {
        std::string section;
        std::string key;
        if (!splitKey(entry.first, section, key)) {
            continue;
        }
        if (section != currentSection) {
            if (!output.empty()) {
                output.push_back("");
            }
            if (!section.empty()) {
                output.push_back("[" + section + "]");
            }
            currentSection = section;
        }
        output.push_back(key + "=" + entry.second);
    }

    std::ofstream file(m_filePath, std::ios::trunc);
    if (!file.is_open()) {
        return false;
    }
    if (output.empty()) {
        // No previous file: emit a self documenting header.
        file << "; 24 h Boiler Scheduler - configuration file\n";
        file << "; Written by the emulator. Safe to edit by hand, then press 'R' to reload.\n";
        file << "; Window rule: start at `start` (local time) for `duration_min` minutes,\n";
        file << "; windows may cross midnight. Duration is limited to 5..360 minutes.\n\n";
        std::string emitted;
        for (const auto& entry : m_entries) {
            std::string section;
            std::string key;
            if (!splitKey(entry.first, section, key)) {
                continue;
            }
            if (section != emitted) {
                if (!emitted.empty()) {
                    file << "\n";
                }
                if (!section.empty()) {
                    file << "[" << section << "]\n";
                }
                emitted = section;
            }
            file << key << "=" << entry.second << "\n";
        }
    } else {
        for (const std::string& line : output) {
            file << line << "\n";
        }
    }

    file.flush();
    return file.good();
}

bool WindowsIniFileStorage::editExistingFile(std::vector<std::string>& output,
                                             std::map<std::string, std::string>& pending) const {
    std::ifstream input(m_filePath);
    if (!input.is_open()) {
        return false;
    }

    std::string section;
    std::string line;
    while (std::getline(input, line)) {
        const std::string trimmed = trim(line);
        if (trimmed.empty() || trimmed[0] == ';' || trimmed[0] == '#') {
            output.push_back(line);
            continue;
        }
        if (trimmed.front() == '[' && trimmed.back() == ']') {
            section = toLower(trim(trimmed.substr(1, trimmed.size() - 2)));
            output.push_back(line);
            continue;
        }
        const size_t equals = trimmed.find('=');
        if (equals == std::string::npos) {
            output.push_back(line);
            continue;
        }
        const std::string key = toLower(trim(trimmed.substr(0, equals)));
        const std::string fullKey = section.empty() ? key : section + "." + key;
        const auto found = m_entries.find(fullKey);
        if (found != m_entries.end()) {
            output.push_back(key + "=" + found->second); // Keep the author's key spelling
            pending.erase(found->first);
        } else {
            output.push_back(line); // Key dropped in memory: keep the file entry
        }
    }
    return true;
}

bool WindowsIniFileStorage::getString(const std::string& key, std::string& value) const {
    std::string section;
    std::string leaf;
    if (!splitKey(key, section, leaf)) {
        return false;
    }
    const std::string fullKey = section.empty() ? leaf : section + "." + leaf;
    const auto it = m_entries.find(fullKey);
    if (it == m_entries.end()) {
        return false;
    }
    value = it->second;
    return true;
}

bool WindowsIniFileStorage::setString(const std::string& key, const std::string& value) {
    std::string section;
    std::string leaf;
    if (!splitKey(key, section, leaf)) {
        return false;
    }
    const std::string fullKey = section.empty() ? leaf : section + "." + leaf;
    m_entries[fullKey] = value;
    return true;
}

bool WindowsIniFileStorage::getInt(const std::string& key, long& value) const {
    std::string text;
    if (!getString(key, text)) {
        return false;
    }
    char* end = nullptr;
    const long parsed = std::strtol(text.c_str(), &end, 10);
    if (end == text.c_str()) {
        return false;
    }
    value = parsed;
    return true;
}

bool WindowsIniFileStorage::setInt(const std::string& key, long value) {
    return setString(key, std::to_string(value));
}

bool WindowsIniFileStorage::getBool(const std::string& key, bool& value) const {
    std::string text;
    if (!getString(key, text)) {
        return false;
    }
    return parseBool(text, value);
}

bool WindowsIniFileStorage::setBool(const std::string& key, bool value) {
    return setString(key, value ? "true" : "false");
}

bool WindowsIniFileStorage::remove(const std::string& key) {
    std::string section;
    std::string leaf;
    if (!splitKey(key, section, leaf)) {
        return false;
    }
    const std::string fullKey = section.empty() ? leaf : section + "." + leaf;
    return m_entries.erase(fullKey) > 0;
}

} // namespace hal
} // namespace arduino
