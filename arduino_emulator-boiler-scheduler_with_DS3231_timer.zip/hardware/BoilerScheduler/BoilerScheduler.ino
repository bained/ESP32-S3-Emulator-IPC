/*
 * ============================================================================
 *  24 h Boiler Scheduler - WeMos D1 mini PRO + DS3231 + SSR-40DA
 * ============================================================================
 *  Board       : LOLIN(WEMOS) D1 mini PRO (ESP8266, 16 MB flash)
 *  Arduino IDE : esp8266 core >= 3.1, libraries: RTClib (Adafruit), Wire
 *
 *  WIRING (do NOT connect mains yourself unless you are qualified):
 *
 *   230 V AC --[FUSE]--[HLK-PM01 AC in L/N]
 *   230 V AC ------+-------------------(SSR-40DA: AC output terminals)
 *                  |                             |
 *               Boiler element ----------------+
 *
 *   HLK-PM01 DC out:  +5V -> D1 mini PRO "5V"   GND -> "G" (GND)
 *   DS3231:  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)   VCC -> 3V3   GND -> GND
 *            CR2032 installed, SQW not used.
 *   SSR-40DA: "+" IN -> D5 (GPIO14)   "-" IN -> GND of the *ESP* supply
 *
 *  *** GALVANIC ISOLATION ***
 *  The SSR input side is opto-isolated from the AC side, and the HLK-PM01 is
 *  isolated from mains, so the ESP side is safe to touch / flash *only* if the
 *  SSR is a genuine opto-isolated device. The cheap "SSR-40DA" clones are
 *  known to be isolated through a resistor network only; verify by measuring
 *  the resistance between IN- and AC terminals (should be > 10 MOhm).
 *
 *  Configuration: identical INI file used by the emulator, on LittleFS:
 *      /boiler.ini      (see the emulator's config/boiler.ini for the keys)
 *  Upload it once with "Tools -> ESP8266 Sketch Data Upload".
 *
 *  Serial (115200) commands, one per line:
 *      T=2026-10-31 18:45:00   set the DS3231 time (also clears the OSF)
 *      B=30                    manual boost for 30 minutes
 *      X                       cancel boost
 *      C                       clear safety latch
 *      R                       reload /boiler.ini
 *      S / H                   status / help
 * ============================================================================
 */

#include <Arduino.h>
#include <Wire.h>
#include <RTClib.h>
#include <LittleFS.h>

// ---------------------------------------------------------------- constants
constexpr uint8_t  SSR_PIN          = D5;    // GPIO14 on the D1 mini PRO
constexpr bool     SSR_ACTIVE_LOW   = true;  // Most SSR-40DA modules: LOW = ON
constexpr uint8_t  RTC_SDA_PIN      = D2;    // GPIO4
constexpr uint8_t  RTC_SCL_PIN      = D1;    // GPIO5
constexpr uint32_t SERIAL_BAUD      = 115200;
constexpr const char* CONFIG_PATH   = "/boiler.ini";
constexpr const char* DEFAULT_TZ_MIN = "180"; // UTC+3 (Europe/Sofia, no DST)

RTC_DS3231 rtc;

// ------------------------------------------------------------------- config
struct WindowConfig {
    bool     enabled  = false;
    uint32_t start    = 0;      // seconds of local day
    uint32_t duration = 0;      // seconds
};

struct Config {
    WindowConfig window1{true, 6 * 3600 + 30 * 60, 60 * 60}; // 06:30 for 60 min
    WindowConfig window2{true, 22 * 3600,          30 * 60}; // 22:00 for 30 min
    int32_t  tzOffset     = 3 * 3600;
    uint32_t cooldownSec  = 60;
    uint32_t safetyMin    = 120;
} cfg;

// -------------------------------------------------------------------- state
enum Phase { PHASE_IDLE, PHASE_HEATING, PHASE_COOLDOWN };

Phase    phase            = PHASE_IDLE;
bool     relayOn          = false;
bool     safetyLatched    = false;
bool     boostActive      = false;
uint32_t boostUntilEpoch  = 0;
bool     windowActive[2]  = {false, false};
uint32_t continuousOnSec  = 0;
uint32_t cooldownLeftSec  = 0;
uint32_t lastEpoch        = 0;
bool     haveLastEpoch    = false;
uint32_t lastReportMs     = 0;
String   serialLine;

// ----------------------------------------------------------------- utilities
uint32_t parseClock(const String& text) {
    // "HH:MM" or "HH:MM:SS" -> seconds of day, 0xFFFFFFFF on error
    int h = 0, m = 0, s = 0;
    const int count = sscanf(text.c_str(), "%d:%d:%d", &h, &m, &s);
    if (count < 2 || h < 0 || h > 23 || m < 0 || m > 59 || s < 0 || s > 59) {
        return 0xFFFFFFFFu;
    }
    return static_cast<uint32_t>(h) * 3600u + static_cast<uint32_t>(m) * 60u +
           static_cast<uint32_t>(s);
}

String clockText(uint32_t secondsOfDay) {
    char buf[8];
    snprintf(buf, sizeof(buf), "%02u:%02u", (secondsOfDay / 3600u) % 24u,
             (secondsOfDay % 3600u) / 60u);
    return String(buf);
}

// Reads "section.key" style values out of the INI file (case insensitive keys).
bool readIniValue(const String& key, String& out) {
    File file = LittleFS.open(CONFIG_PATH, "r");
    if (!file) {
        return false;
    }
    String section;
    bool found = false;
    while (file.available()) {
        String line = file.readStringUntil('\n');
        line.trim();
        if (line.length() == 0 || line.startsWith(";") || line.startsWith("#")) {
            continue;
        }
        if (line.startsWith("[") && line.endsWith("]")) {
            section = line.substring(1, line.length() - 1);
            section.trim();
            continue;
        }
        const int equals = line.indexOf('=');
        if (equals < 0) {
            continue;
        }
        String fullKey = section + "." + line.substring(0, equals);
        fullKey.trim();
        if (fullKey.equalsIgnoreCase(key)) {
            out = line.substring(equals + 1);
            out.trim();
            found = true;
            break;
        }
    }
    file.close();
    return found;
}

void loadConfig() {
    if (!LittleFS.exists(CONFIG_PATH)) {
        Serial.printf("[Config] %s not found - using compiled defaults.\n", CONFIG_PATH);
        return;
    }
    String value;

    if (readIniValue("window1.enabled", value))    cfg.window1.enabled = value.equalsIgnoreCase("true") || value == "1";
    if (readIniValue("window1.start", value))      cfg.window1.start = parseClock(value);
    if (readIniValue("window1.duration_min", value)) cfg.window1.duration = value.toInt() * 60UL;

    if (readIniValue("window2.enabled", value))    cfg.window2.enabled = value.equalsIgnoreCase("true") || value == "1";
    if (readIniValue("window2.start", value))      cfg.window2.start = parseClock(value);
    if (readIniValue("window2.duration_min", value)) cfg.window2.duration = value.toInt() * 60UL;

    if (readIniValue("time.timezone_min", value))  cfg.tzOffset = value.toInt() * 60L;
    if (readIniValue("control.cooldown_sec", value)) cfg.cooldownSec = value.toInt();
    if (readIniValue("control.safety_limit_min", value)) cfg.safetyMin = value.toInt();

    // Defensive clamps: never allow a 24 h heater from a broken file.
    cfg.window1.duration = constrain(cfg.window1.duration, 300UL, 6UL * 3600UL);
    cfg.window2.duration = constrain(cfg.window2.duration, 300UL, 6UL * 3600UL);
    if (cfg.window1.start == 0xFFFFFFFFu) cfg.window1.start = 6 * 3600 + 30 * 60;
    if (cfg.window2.start == 0xFFFFFFFFu) cfg.window2.start = 22 * 3600;
    cfg.cooldownSec = min(cfg.cooldownSec, 3600UL);

    Serial.printf("[Config] W1 %s %s +%lu min | W2 %s %s +%lu min | UTC%+d min\n",
                  cfg.window1.enabled ? "on " : "off", clockText(cfg.window1.start).c_str(),
                  cfg.window1.duration / 60UL, cfg.window2.enabled ? "on " : "off",
                  clockText(cfg.window2.start).c_str(), cfg.window2.duration / 60UL,
                  static_cast<int>(cfg.tzOffset / 60));
}

// -------------------------------------------------------------------- relay
void writeRelay(bool on) {
    relayOn = on;
    // Active LOW module: LOW closes the SSR, HIGH releases it.
    digitalWrite(SSR_PIN, (on != SSR_ACTIVE_LOW) ? LOW : HIGH);
}

// ---------------------------------------------------------------- scheduler
bool inWindow(const WindowConfig& w, uint32_t localSecond) {
    if (!w.enabled || w.duration == 0) {
        return false;
    }
    for (int8_t dayOffset = -1; dayOffset <= 0; ++dayOffset) {
        const int64_t start = static_cast<int64_t>(dayOffset) * 86400 + w.start;
        if (static_cast<int64_t>(localSecond) >= start &&
            static_cast<int64_t>(localSecond) < start + static_cast<int64_t>(w.duration)) {
            return true;
        }
    }
    return false;
}

void scheduleUpdate() {
    const DateTime now = rtc.now();
    const uint32_t utcEpoch = now.unixtime();
    const int64_t localEpoch = static_cast<int64_t>(utcEpoch) + cfg.tzOffset;
    const uint32_t localSecond = static_cast<uint32_t>(
        ((localEpoch % 86400) + 86400) % 86400);

    int32_t delta = haveLastEpoch ? static_cast<int32_t>(utcEpoch - lastEpoch) : 0;
    if (delta < 0 || delta > 3600) {
        delta = 0; // Clock set backwards / RTC step
    }

    if (!haveLastEpoch) {
        windowActive[0] = inWindow(cfg.window1, localSecond);
        windowActive[1] = inWindow(cfg.window2, localSecond);
    }

    bool anyActive = false;
    const WindowConfig* windows[2] = {&cfg.window1, &cfg.window2};
    for (uint8_t i = 0; i < 2; ++i) {
        const bool active = inWindow(*windows[i], localSecond);
        if (active && !windowActive[i]) {
            Serial.printf("[Schedule] Window %u STARTED at %s\n", i + 1,
                          clockText(windows[i]->start).c_str());
            boostActive = false; // A scheduled window takes over
        } else if (!active && windowActive[i]) {
            Serial.println("[Schedule] Window finished");
        }
        windowActive[i] = active;
        anyActive |= active;
    }

    if (boostActive && utcEpoch >= boostUntilEpoch) {
        boostActive = false;
        Serial.println("[Schedule] Boost expired");
    }

    bool wantHeat = !safetyLatched && (anyActive || boostActive);

    if (wantHeat) {
        continuousOnSec += static_cast<uint32_t>(delta);
        if (cfg.safetyMin > 0 && continuousOnSec > cfg.safetyMin * 60UL) {
            safetyLatched = true;
            wantHeat = false;
            Serial.printf("[Safety] Continuous ON exceeded %lu min - latched OFF\n",
                          cfg.safetyMin);
        }
    } else {
        continuousOnSec = 0;
    }

    if (wantHeat) {
        phase = PHASE_HEATING;
        cooldownLeftSec = 0;
    } else if (phase == PHASE_HEATING) {
        if (cfg.cooldownSec > 0 && !safetyLatched) {
            phase = PHASE_COOLDOWN;
            cooldownLeftSec = cfg.cooldownSec;
            wantHeat = true;
        } else {
            phase = PHASE_IDLE;
        }
    } else if (phase == PHASE_COOLDOWN) {
        const uint32_t step = static_cast<uint32_t>(delta);
        cooldownLeftSec = (step >= cooldownLeftSec) ? 0 : cooldownLeftSec - step;
        if (cooldownLeftSec > 0) {
            wantHeat = true;
        } else {
            phase = PHASE_IDLE;
        }
    }

    writeRelay(wantHeat);
    lastEpoch = utcEpoch;
    haveLastEpoch = true;
}

// -------------------------------------------------------------- serial cmds
void printStatus() {
    const DateTime now = rtc.now();
    const uint32_t localEpoch = static_cast<uint32_t>(
        static_cast<int64_t>(now.unixtime()) + cfg.tzOffset);
    const DateTime local(localEpoch); // RTClib: seconds since 2000-01-01
    const char* phaseName = (phase == PHASE_HEATING) ? "HEATING"
                            : (phase == PHASE_COOLDOWN) ? "COOLDOWN" : "IDLE";
    Serial.printf("[Status] %04d-%02d-%02d %02d:%02d:%02d | %s | SSR %s | ON %lu min\n",
                  local.year(), local.month(), local.day(), local.hour(), local.minute(),
                  local.second(), phaseName, relayOn ? "ON" : "OFF", continuousOnSec / 60UL);
    if (safetyLatched) {
        Serial.println("[Status] FAULT: safety latch active ('C' to clear)");
    }
}

void handleSerial() {
    while (Serial.available()) {
        const char c = static_cast<char>(Serial.read());
        if (c == '\r') {
            continue;
        }
        if (c != '\n') {
            serialLine += c;
            if (serialLine.length() > 96) {
                serialLine = "";
            }
            continue;
        }
        serialLine.trim();
        if (serialLine.length() == 0) {
            continue;
        }

        if (serialLine.startsWith("T=") || serialLine.startsWith("t=")) {
            // T=YYYY-MM-DD HH:MM:SS -> set the DS3231 and clear the OSF flag.
            int y, mo, d, h, mi, s;
            if (sscanf(serialLine.c_str() + 2, "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &s) == 6) {
                rtc.adjust(DateTime(y, mo, d, h, mi, s));
                haveLastEpoch = false;
                Serial.println("[RTC] Time written, OSF cleared.");
            } else {
                Serial.println("[RTC] Usage: T=2026-10-31 18:45:00");
            }
        } else if (serialLine.startsWith("B=") || serialLine.startsWith("b=")) {
            const uint32_t minutes = serialLine.substring(2).toInt();
            boostActive = (minutes > 0 && minutes <= 180);
            boostUntilEpoch = rtc.now().unixtime() + minutes * 60UL;
            Serial.printf("[Boost] %lu min\n", minutes);
        } else if (serialLine.equalsIgnoreCase("X")) {
            boostActive = false;
            Serial.println("[Boost] cancelled");
        } else if (serialLine.equalsIgnoreCase("C")) {
            safetyLatched = false;
            continuousOnSec = 0;
            haveLastEpoch = false;
            Serial.println("[Safety] cleared");
        } else if (serialLine.equalsIgnoreCase("R")) {
            loadConfig();
            haveLastEpoch = false;
        } else if (serialLine.equalsIgnoreCase("S")) {
            printStatus();
        } else if (serialLine.equalsIgnoreCase("H")) {
            Serial.println("T=<time> | B=<min> | X | C | R | S | H");
        } else {
            Serial.println("[Cmd] Unknown command ('H' for help)");
        }
        serialLine = "";
    }
}

// ------------------------------------------------------------------- sketch
void setup() {
    // SAFE STATE FIRST: drive the SSR input to "off" before any pin mode change.
    digitalWrite(SSR_PIN, SSR_ACTIVE_LOW ? HIGH : LOW);
    pinMode(SSR_PIN, OUTPUT);
    writeRelay(false);

    Serial.begin(SERIAL_BAUD);
    Serial.println("\n=== D1 mini PRO 24h Boiler Scheduler ===");

    if (!LittleFS.begin()) {
        Serial.println("[FS] LittleFS mount failed - defaults will be used.");
    }
    loadConfig();

    Wire.begin(RTC_SDA_PIN, RTC_SCL_PIN);
    if (!rtc.begin()) {
        Serial.println("[RTC] DS3231 not found! Heating is REFUSED until it responds.");
        while (true) {
            writeRelay(false);
            delay(1000);
        }
    }
    if (rtc.lostPower()) {
        Serial.println("[RTC] Power loss detected (OSF set). Time is NOT trustworthy.");
        // The OSF flag is cleared automatically by the next rtc.adjust() call,
        // which is why the time must be written once with the T= command:
        //   T=2026-10-31 18:45:00
        // Until then the schedule still runs, but against a wrong clock.
    }
    Serial.printf("[RTC] DS3231 temperature: %.2f C\n", rtc.getTemperature());

    scheduleUpdate();
    printStatus();
}

void loop() {
    handleSerial();
    scheduleUpdate();

    if (millis() - lastReportMs >= 60000UL) {
        lastReportMs = millis();
        printStatus();
    }
    delay(200);
}
