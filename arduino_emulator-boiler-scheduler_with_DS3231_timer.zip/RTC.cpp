#include "RTC.h"

namespace arduino {

// ==========================================
// SimulatedRTC
// ==========================================

SimulatedRTC::SimulatedRTC(hal::ITimer& timer, const datetime::DateTime& startTime)
    : m_timer(timer),
      m_start(datetime::normalize(startTime)),
      m_startEpoch(datetime::toEpoch(datetime::normalize(startTime))),
      m_shiftSeconds(0),
      m_pausedAt(-1),
      m_lostPower(false),
      m_responding(true),
      m_timeScale(1) {}

int64_t SimulatedRTC::nowEpoch() {
    const int64_t ticks = (m_pausedAt >= 0)
                              ? m_pausedAt
                              : static_cast<int64_t>(m_timer.getMillis() / 1000ull) *
                                    static_cast<int64_t>(m_timeScale);
    return m_startEpoch + ticks + m_shiftSeconds;
}

datetime::DateTime SimulatedRTC::now() {
    return datetime::fromEpoch(nowEpoch());
}

bool SimulatedRTC::setDateTime(const datetime::DateTime& dt) {
    // Re-anchor the simulation: keep the elapsed tick count, move the origin.
    const int64_t elapsedTicks = nowEpoch() - m_startEpoch;
    m_start = datetime::normalize(dt);
    m_startEpoch = datetime::toEpoch(m_start);
    m_shiftSeconds = 0;
    if (m_pausedAt >= 0) {
        m_pausedAt = 0; // A paused clock stays paused but starts from the new origin
    } else {
        m_startEpoch -= elapsedTicks;
    }
    m_lostPower = false;
    return true;
}

void SimulatedRTC::shift(int64_t seconds) {
    m_shiftSeconds += seconds;
}

void SimulatedRTC::pause() {
    if (m_pausedAt < 0) {
        m_pausedAt = static_cast<int64_t>(m_timer.getMillis() / 1000ull);
    }
}

void SimulatedRTC::resume() {
    if (m_pausedAt >= 0) {
        // Fold the frozen period into the manual shift so time does not jump back.
        const int64_t frozen = static_cast<int64_t>(m_timer.getMillis() / 1000ull) - m_pausedAt;
        m_shiftSeconds += frozen;
        m_pausedAt = -1;
    }
}

// ==========================================
// RTCFacade
// ==========================================

datetime::DateTime RTCFacade::now() {
    if (m_rtc != nullptr) {
        return m_rtc->now();
    }
    return datetime::DateTime{2026, 1, 1, 0, 0, 0};
}

bool RTCFacade::lostPower() const {
    return m_rtc != nullptr ? m_rtc->lostPower() : true;
}

bool RTCFacade::setDateTime(const datetime::DateTime& dt) {
    return m_rtc != nullptr ? m_rtc->setDateTime(dt) : false;
}

void RTCFacade::shift(int64_t seconds) {
    if (m_rtc != nullptr) {
        m_rtc->shift(seconds);
    }
}

void RTCFacade::pause() {
    if (m_rtc != nullptr) {
        m_rtc->pause();
    }
}

void RTCFacade::resume() {
    if (m_rtc != nullptr) {
        m_rtc->resume();
    }
}

bool RTCFacade::isPaused() const {
    return m_rtc != nullptr ? m_rtc->isPaused() : false;
}

const char* RTCFacade::stateFileName() {
    return "config/rtc_state.ini";
}

} // namespace arduino

// Global instance of the RTC facade
arduino::RTCFacade RTC;
