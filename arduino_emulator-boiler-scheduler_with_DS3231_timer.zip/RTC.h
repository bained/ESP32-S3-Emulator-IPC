#pragma once

#include "../Logic/IClock.h"
#include "../HAL/ITimer.h"

namespace arduino {

// Emulator-side simulation of the wiring around the DS3231.
//
// There is no real RTC chip under the emulator, so this class plays the role of
// the whole time subsystem: it keeps a UTC date/time that advances with the
// WindowsTimer, remembers whether the RTC backup battery was lost and exposes
// the "jump forward" facility used by the console debug keys.
//
// It implements logic::IClock, therefore the application code (Logic layer and
// sketch) only ever sees the IClock interface - exactly like on the real board,
// where a Ds3231Bus implementation would be injected instead.
class SimulatedRTC : public logic::IClock {
public:
    SimulatedRTC(hal::ITimer& timer, const datetime::DateTime& startTime);

    datetime::DateTime now() override;
    bool lostPower() const override { return m_lostPower; }
    bool setDateTime(const datetime::DateTime& dt) override;
    const char* sourceName() const override { return "Simulated-DS3231"; }

    // --- Emulator controls -------------------------------------------------
    // Fast-forwards (or rewinds) the simulated RTC.
    void shift(int64_t seconds);

    // Freezes the clock at the current value (simulates mcu deep sleep).
    void pause();
    void resume();
    bool isPaused() const { return m_pausedAt >= 0; }

    // Value handed over to the sketch as the RTC start time.
    datetime::DateTime getStartTime() const { return m_start; }

    // Acceleration factor (1 = real time). Emulator debug facility that lets the
    // whole 24 h schedule be verified in a couple of minutes.
    void setTimeScale(uint32_t scale) { m_timeScale = (scale == 0) ? 1u : scale; }
    uint32_t getTimeScale() const { return m_timeScale; }

    // Set to false to emulate a board whose RTC rejects all I2C transfers.
    void setResponding(bool responding) { m_responding = responding; }
    bool isResponding() const { return m_responding; }

    // Seconds of simulated time elapsed since boot.
    int64_t elapsed() { return nowEpoch() - m_startEpoch; }

private:
    hal::ITimer& m_timer;
    datetime::DateTime m_start;
    int64_t m_startEpoch;      // UTC epoch of m_start
    int64_t m_shiftSeconds;    // Manual offset applied by shift()
    int64_t m_pausedAt;        // Timer value when pause() was called, -1 = running
    bool m_lostPower;          // OSC stop flag (first boot without battery)
    bool m_responding;         // False = RTC chip does not answer on I2C
    uint32_t m_timeScale;      // Emulated seconds per real second

    int64_t nowEpoch();
};

// Global facade, mirroring the `Serial` pattern: the sketch talks to `RTC`
// exactly as it would talk to a DS3231 driver object on the real board.
class RTCFacade {
public:
    void attach(SimulatedRTC* rtc) { m_rtc = rtc; }

    bool available() const { return m_rtc != nullptr; }

    datetime::DateTime now();
    bool lostPower() const;
    bool setDateTime(const datetime::DateTime& dt);

    // Console controls (no-ops when the emulator RTC is not attached).
    void shift(int64_t seconds);
    void pause();
    void resume();
    bool isPaused() const;

    // Path of the persisted simulated RTC state.
    static const char* stateFileName();

private:
    SimulatedRTC* m_rtc = nullptr;
};

} // namespace arduino

// Global RTC facade (defined in RTC.cpp), usable from the sketch.
extern arduino::RTCFacade RTC;
