@echo off
REM ============================================================
REM  Runs any command inside the MSVC environment so that
REM  cl.exe / cmake.exe can find the Windows SDK headers.
REM  Usage:  scripts\msvc.cmd cmake --build build --config Release
REM ============================================================
set "VCVARS="
for %%P in (
    "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
    "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
    "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat"
    "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
    "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
    "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
    "C:\Program Files\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
    "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
) do (
    if not defined VCVARS if exist %%P set "VCVARS=%%~P"
)

if not defined VCVARS (
    echo [msvc] vcvars64.bat not found - install "Desktop development with C++".
    exit /b 1
)

call "%VCVARS%" >nul
%*
exit /b %ERRORLEVEL%
