@echo off
REM ============================================================
REM  Production build: optimised, no debug symbols,
REM  result -> out\boiler_scheduler.exe  (+ config\boiler.ini)
REM  Usage:  build.cmd            (Release)
REM          build.cmd Debug      (only for debugging)
REM ============================================================
setlocal
set "CONFIG=%~1"
if "%CONFIG%"=="" set "CONFIG=Release"

cd /d "%~dp0"

where cmake >nul 2>nul
if errorlevel 1 (
    echo [build] cmake not on PATH - using scripts\msvc.cmd wrapper.
    set "CM=scripts\msvc.cmd cmake"
) else (
    set "CM=cmake"
)

%CM% -S . -B build -DCMAKE_BUILD_TYPE=%CONFIG%
if errorlevel 1 goto :fail

%CM% --build build --config %CONFIG%
if errorlevel 1 goto :fail

if not exist out mkdir out
copy /y "build\%CONFIG%\boiler_scheduler.exe" "out\boiler_scheduler.exe" >nul
if not exist out\config mkdir out\config
if exist config\boiler.ini copy /y "config\boiler.ini" "out\config\boiler.ini" >nul

echo.
echo [build] OK -^> out\boiler_scheduler.exe  (%CONFIG%)
echo [build] Run it from the "out" folder:  out\boiler_scheduler.exe
exit /b 0

:fail
echo.
echo [build] FAILED
exit /b 1
