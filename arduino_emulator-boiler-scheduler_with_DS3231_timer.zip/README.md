# 24 h Boiler Scheduler — WeMos D1 mini PRO + DS3231 + SSR-40DA

Galvanically isolated controller that heats a boiler **twice a day** (daytime +
night window, 30–60 min each). No access point, no web server — every parameter
lives in a plain-text INI file.

This repository contains **only** the files needed by this project. It is a
standalone cut of the ESP32-S3 emulator with everything unrelated removed.

---

## Quick start (production build)

```bat
build.cmd
out\boiler_scheduler.exe
```

`build.cmd` produces an optimised Release binary in `out\boiler_scheduler.exe`
with **no debug symbols** and a statically linked CRT (runs on a clean Windows
installation, no VC++ redistributable required). It also copies
`config\boiler.ini` next to it.

Manual equivalent:

```bat
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

If `cmake` / `cl` are not on your `PATH`, use the wrapper that loads the MSVC
environment first:

```bat
scripts\msvc.cmd cmake -S . -B build
scripts\msvc.cmd cmake --build build --config Release
```

### Build configuration

| Setting | Value |
| :--- | :--- |
| Default build type | `Release` |
| Optimisation | `/O2 /GL` + `/LTCG /OPT:REF /OPT:ICF` |
| Debug information | disabled (`/DEBUG:NONE`, no `.pdb`) |
| Runtime library | static `/MT` (release) |
| Binary size | ~356 KB |
| Compiler warnings | `/W4`, build is warning-free |

---

## What is in the box

```
main.cpp                    Sketch: wiring + setup()/loop() (emulator entry point)
RTC.h / RTC.cpp             Simulated RTC façade (IClock) + BOILER_TIME_SCALE
Core/                       Arduino types/constants + calendar math (DateTimeTypes.h)
GPIO/                       pinMode/digitalWrite/digitalRead/analogRead/Write
HAL/                        IConsole, ITimer, IStorage, IInputSource, IExternalSensor
                            + WindowsConsole, WindowsTimer, WindowsConsoleInput,
                              WindowsIniFileStorage
Logic/IClock.h              Clock abstraction
Logic/Ds3231Rtc.*           DS3231 driver (register-level state)
Logic/BoilerScheduler.*     The schedule state machine (pure C++, unit tested)
Logic/SSRRelay.*            SSR output with safe-boot ordering and polarity
Logic/BoilerController.*    Orchestration + INI persistence
Runtime/, Serial/, Timing/, Utilities/, include/Arduino.h
config/boiler.ini           The configuration file (see below)
hardware/BoilerScheduler/   Arduino sketch for the real ESP8266 board
tests/BoilerSchedulerTest.cpp
scripts/msvc.cmd            MSVC environment wrapper
build.cmd                   One-command production build
```

---

## Configuration (`config/boiler.ini`)

```ini
[window1]                ; daytime boost
enabled=true
start=06:30
duration_min=60

[window2]                ; night boost
enabled=true
start=22:00
duration_min=30

[time]
timezone_min=180         ; local = UTC + 3 h (use 120 for UTC+2 summer time)

[control]
cooldown_sec=60          ; thermal keep-alive after the window
safety_limit_min=120     ; continuous-ON guard (0 = disabled)

[ssr]
pin=5                    ; emulator virtual pin; hardware: D5 = GPIO14
active_low=false         ; most SSR-40DA clones need true

[system]
report_interval_ms=10000
quiet_at_night=true

[override]
active=false             ; persisted manual boost
```

* Windows may cross midnight (`23:30` + 60 min ends at `00:30` next day).
* Durations are clamped to 5…360 min, so a typo cannot heat the boiler all day.
* Comments and blank lines in the file are preserved when the program rewrites it.
* Apply changes with `R` in the emulator console — no restart needed.

---

## Running

```bat
out\boiler_scheduler.exe      (run from the folder that contains config\)
```

Debug keys (single key, no Enter):

| Key | Action |
| :--- | :--- |
| `]` / `[` | Move the simulated RTC ±15 minutes |
| `b` | Manual boost for 30 minutes (persisted) |
| `c` | Clear the safety latch |
| `r` | Reload `config/boiler.ini` |
| `s` | Print the configuration |
| `h` | Help |
| `Esc` | Exit (relay forced OFF) |

`BOILER_TIME_SCALE=<n>` accelerates the simulated RTC (`900` → a whole day in
96 seconds), which is how the midnight crossing is verified.

---

## Self tests

```bat
scripts\msvc.cmd cmake -S . -B build_tests -DBUILD_TESTS=ON
scripts\msvc.cmd cmake --build build_tests --config Release
scripts\msvc.cmd ctest --test-dir build_tests -C Release --output-on-failure
```

31 checks: normal window + keep-alive, midnight crossing, disabled windows,
boost start/expiry/persistence, safety latch and re-arming, RTC set backwards.

---

## Real hardware

See `hardware/BoilerScheduler/BoilerScheduler.ino` for the ESP8266 sketch
(D1 mini PRO, DS3231 over I2C, SSR on D5, LittleFS config). It implements the
same behaviour and reads the same INI keys.

> ⚠️ This project switches **mains voltage**. The HLK-PM01 and a genuine
> opto-isolated SSR provide the isolation — verify a cheap "SSR-40DA" clone with
> a multimeter (resistance between `IN-` and the AC terminals must be
> multi-megaohm) before trusting it. Have the mains side checked by a qualified
> electrician.
