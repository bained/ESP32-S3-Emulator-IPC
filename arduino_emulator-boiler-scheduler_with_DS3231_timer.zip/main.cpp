#include "include/Arduino.h"
#include "Runtime/Runtime.h"
#include "GPIO/GPIOManager.h"
#include "HAL/WindowsIniFileStorage.h"
#include "HAL/WindowsConsoleInput.h"
#include "HAL/WindowsTimer.h"
#include "Logic/BoilerController.h"
#include "Logic/BoilerScheduler.h"
#include "Logic/Ds3231Rtc.h"
#include "Logic/SSRRelay.h"

#include <string>
#include <cstdlib>
#include <cstdio>
#include <cstdint>

// ==========================================
// 24 h Boiler Scheduler - WeMos D1 mini PRO
// ==========================================
// Hardware (galvanically isolated):
//   HLK-PM01 (230 V AC -> 5 V DC)         -> D1 mini PRO 5V / GND
//   DS3231 module (I2C: SCL=D1, SDA=D2, VCC=3V3, GND) + CR2032 cell
//   SSR-40DA (DC controlled AC relay) IN  -> D5 / GPIO5, GND common with ESP GND
//   Boiler element switched by the SSR on the AC side.
//
// Every tunable parameter (window times, durations, SB polarity, timezone, ...)
// lives in config/boiler.ini: there is no access point and no web server.
// ---------------------------------------------------------------

constexpr uint8_t SSR_PIN = 5; // WeMos D1 mini PRO: D5 / GPIO5

// ---- Emulator wiring ----
static arduino::hal::WindowsTimer g_timer;
static arduino::hal::WindowsIniFileStorage g_configStorage(
    arduino::logic::BoilerController::defaultFileName());
static arduino::hal::WindowsConsoleInput g_consoleInput;

// ---- Clock: DS3231 emulation (the RTCFacade is what the sketch sees) ----
static arduino::SimulatedRTC g_simulatedClock(g_timer, arduino::datetime::DateTime{2026, 1, 1, 0, 0, 0});
static arduino::logic::Ds3231Rtc g_rtc(g_simulatedClock);

// ---- Actuator + control logic (hardware independent) ----
static arduino::logic::SSRRelay g_relay(SSR_PIN, false);
static arduino::logic::BoilerScheduler g_scheduler;
static arduino::logic::BoilerController g_controller(g_scheduler, g_rtc, g_relay, g_configStorage);

// ---- Serial command buffer (same commands as the real ESP32 sketch) ----
static std::string g_serialCommand;
static bool g_exitRequested = false;

// ==========================================
// Helper functions
// ==========================================

// How many minutes the ']' / '[' keys move the simulated RTC.
constexpr int64_t RTC_STEP_MINUTES = 15;

// Converts a UTC clock value into local time using the configured offset.
static arduino::datetime::DateTime toLocal(const arduino::datetime::DateTime& utc) {
    return arduino::datetime::fromEpoch(arduino::datetime::toEpoch(utc) +
                                        g_controller.config().timezoneOffset);
}

// Picks a start time for the simulated RTC: the earliest enabled window start of
// the day. This makes the demo start inside a meaningful daily context.
static arduino::datetime::DateTime pickRtcStartTime() {
    const arduino::logic::BoilerConfig& cfg = g_controller.config();
    const arduino::datetime::DateTime localNow{2026, 1, 1, 0, 0, 0};

    int64_t chosen = -1;
    for (size_t i = 0; i < arduino::logic::BoilerScheduler::MAX_WINDOWS; ++i) {
        if (!cfg.windowEnabled[i]) {
            continue;
        }
        const int64_t candidate =
            arduino::datetime::daysFromCivil(localNow.year, localNow.month, localNow.day) * 86400 +
            static_cast<int64_t>(cfg.windowStart[i]) - cfg.timezoneOffset;
        if (chosen < 0 || candidate < chosen) {
            chosen = candidate;
        }
    }
    if (chosen < 0) {
        return arduino::datetime::fromEpoch(arduino::datetime::toEpoch(localNow) + 6 * 3600);
    }
    return arduino::datetime::fromEpoch(chosen);
}

static void printBanner() {
    Serial.println("==========================================");
    Serial.println("   D1 mini PRO - 24h Boiler Scheduler     ");
    Serial.println("   RTC: DS3231 | Output: SSR-40DA on D5   ");
    Serial.println("==========================================");
}

static void printConfig() {
    const arduino::logic::BoilerConfig& cfg = g_controller.config();
    Serial.printf("[Config] %s (%s)\n",
                  arduino::logic::BoilerController::defaultFileName(),
                  g_configStorage.location().c_str());
    for (size_t i = 0; i < arduino::logic::BoilerScheduler::MAX_WINDOWS; ++i) {
        const arduino::logic::BoilerWindow& w = g_scheduler.getWindow(static_cast<uint8_t>(i));
        Serial.printf("[Config] Window %u: %s  start %s  duration %lu min%s\n",
                      static_cast<unsigned>(i + 1),
                      w.enabled ? "ENABLED " : "disabled",
                      arduino::datetime::formatHHMM(w.start).c_str(),
                      static_cast<unsigned long>(w.duration / 60u),
                      w.crossesMidnight() ? " (crosses midnight)" : "");
    }
    Serial.printf("[Config] Timezone UTC%+d min | cooldown %lu s | safety limit %lu min\n",
                  static_cast<int>(cfg.timezoneOffset / 60),
                  static_cast<unsigned long>(cfg.cooldownSeconds),
                  static_cast<unsigned long>(cfg.safetyLimit / 60u));
    Serial.printf("[Config] SSR pin %u, active %s\n", cfg.ssrPin,
                  cfg.ssrActiveLow ? "LOW" : "HIGH");
}

static void printHelp() {
    Serial.println("------------------------------------------");
    Serial.println(" Debug keys (single key, no Enter needed):");
    Serial.println("   ]  advance simulated RTC by 15 min");
    Serial.println("   [  rewind  simulated RTC by 15 min");
    Serial.println("   b  manual boost for 30 min (persisted)");
    Serial.println("   c  clear safety latch / fault");
    Serial.println("   r  reload config/boiler.ini");
    Serial.println("   s  print status, h  help, Esc exit");
    Serial.println("------------------------------------------");
}

void setup() {
    Serial.begin(115200);
    printBanner();

    // 1. Configuration file (created with defaults when missing).
    g_controller.begin();

    // 2. Optional emulator acceleration (set BOILER_TIME_SCALE=60 to run the
    //    whole day in 24 minutes). Unset or 1 keeps real time.
    if (const char* scaleText = std::getenv("BOILER_TIME_SCALE")) {
        const long scale = std::strtol(scaleText, nullptr, 10);
        if (scale >= 1 && scale <= 3600) {
            g_simulatedClock.setTimeScale(static_cast<uint32_t>(scale));
        }
    }

    // 2. The RTC starts at a moment where the schedule is observable, and the
    //    time source is exposed to the sketch the same way the board does it.
    RTC.attach(&g_simulatedClock);
    RTC.setDateTime(pickRtcStartTime());
    g_rtc.readNow();

    // 3. Boot-time report.
    const arduino::datetime::DateTime local = toLocal(RTC.now());
    Serial.printf("[RTC] %s | local %s UTC%+d min | %s\n",
                  g_simulatedClock.sourceName(), arduino::datetime::format(local).c_str(),
                  static_cast<int>(g_controller.config().timezoneOffset / 60),
                  g_controller.fault().empty() ? "OK" : g_controller.fault().c_str());
    if (RTC.lostPower()) {
        Serial.println("[RTC] DS3231 lost power (OSF set) - time is NOT trustworthy.");
    }

    printConfig();

    // 4. Re-evaluate the schedule with the final clock value.
    g_controller.begin();

    printHelp();
    Serial.println("[Setup] System ready - the 24 h schedule is running.");
}

// ==========================================
// Debug key handling (runs every loop tick)
// ==========================================

static void handleDebugKeys() {
    while (g_consoleInput.available()) {
        const int key = g_consoleInput.read();
        if (key < 0) {
            break;
        }

        if (key == 27) { // Esc: orderly shutdown
            g_exitRequested = true;
            Serial.println("[System] Exit requested - relay forced OFF.");
            break;
        }

        switch (key) {
        case ']':
            g_simulatedClock.shift(15 * 60);
            Serial.println("[RTC] Fast-forward 15 min.");
            break;
        case '[':
            g_simulatedClock.shift(-15 * 60);
            Serial.println("[RTC] Rewind 15 min.");
            break;
        case 'b':
            g_controller.requestBoost(30);
            break;
        case 'c':
            g_controller.clearFault();
            break;
        case 'r':
            if (g_controller.reloadConfig()) {
                Serial.println("[Config] boiler.ini reloaded and applied.");
                printConfig();
            } else {
                Serial.println("[Config] boiler.ini unchanged (or unreadable).");
            }
            break;
        case 's':
            printConfig();
            break;
        case 'h':
        case '?':
            printHelp();
            break;
        default:
            break; // Random typing is ignored
        }
    }
}

// ==========================================
// Status report (throttled to config.reportInterval)
// ==========================================

static void reportStatus() {
    static unsigned long lastReport = 0;
    static bool firstReport = true;
    const unsigned long now = millis();
    if (!firstReport && now - lastReport < g_controller.config().reportInterval) {
        return;
    }
    firstReport = false;
    lastReport = now;

    const arduino::logic::BoilerConfig& cfg = g_controller.config();
    const arduino::datetime::DateTime utc = g_rtc.now();
    const arduino::datetime::DateTime local = toLocal(utc);
    const bool heating = g_scheduler.isHeating();
    const bool cooldown = g_scheduler.getPhase() == arduino::logic::BoilerPhase::COOLDOWN;

    // Outside the heating cycle the report is reduced to a single essential line
    // (the user asked for a quiet 24/7 device, not a chatty serial port).
    if (cfg.quietAtNight && !heating && !cooldown) {
        Serial.printf("[Status] %s | %s | SSR %s\n",
                      arduino::datetime::format(local).c_str(),
                      g_scheduler.phaseName(),
                      g_relay.isOn() ? "ON" : "OFF");
        return;
    }

    // Describe what is happening right now in human terms.
    char detail[96];
    if (g_scheduler.isOverrideActive()) {
        std::snprintf(detail, sizeof(detail), "manual boost, %lu min left",
                      static_cast<unsigned long>(g_scheduler.getOverrideRemaining(
                                                     arduino::datetime::toEpoch(utc)) / 60u));
    } else if (heating || cooldown) {
        const int8_t idx = g_scheduler.getActiveWindowIndex();
        if (idx >= 0) {
            const arduino::logic::BoilerWindow& w =
                g_scheduler.getWindow(static_cast<uint8_t>(idx));
            const uint32_t elapsed = g_scheduler.getCurrentWindowElapsed(utc) / 60u;
            std::snprintf(detail, sizeof(detail),
                          "window %d, %lu / %lu min%s",
                          static_cast<int>(idx) + 1, static_cast<unsigned long>(elapsed),
                          static_cast<unsigned long>(w.duration / 60u),
                          cooldown ? " + keep-alive" : "");
        } else {
            std::snprintf(detail, sizeof(detail), "keep-alive");
        }
    } else {
        const uint32_t until = g_scheduler.secondsUntilNextStart(utc);
        if (until == UINT32_MAX) {
            std::snprintf(detail, sizeof(detail), "no window enabled");
        } else {
            std::snprintf(detail, sizeof(detail), "next window in %lu min",
                          static_cast<unsigned long>((until + 59u) / 60u));
        }
    }

    Serial.printf("[Status] %s | phase %s | SSR %s | %s | switches %lu\n",
                  arduino::datetime::format(local).c_str(), g_scheduler.phaseName(),
                  g_relay.isOn() ? "ON" : "OFF", detail,
                  static_cast<unsigned long>(g_relay.getSwitchingCount()));

    if (g_scheduler.isSafetyLatched()) {
        Serial.println("[Status] FAULT: safety latch active - clear with 'c'.");
    }
}

// ==========================================
// Arduino lifecycle
// ==========================================

void loop() {
    // 1. Read the keyboard debug commands (non-blocking).
    handleDebugKeys();
    if (g_exitRequested) {
        g_relay.set(false);
        delay(200);
        std::exit(0);
    }

    // 2. Run one control step: RTC -> schedule -> SSR.
    g_controller.update();

    // 3. Throttled human readable status.
    reportStatus();

    // 4. Typical Arduino loop pacing (1 s is plenty for a 24 h schedule).
    delay(1000);
}

// ==========================================
// Emulator Entry Point
// ==========================================

int main() {
    arduino::Runtime emulatorRuntime;
    emulatorRuntime.run();
    return 0;
}
