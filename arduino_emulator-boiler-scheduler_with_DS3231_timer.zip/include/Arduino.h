#pragma once

// Arduino.h - Unified entry point for the ESP32-S3 Windows Emulator.
// This header aggregates all modular components, starting with the Core module.

// Include Core Module Types and Constants
#include "../Core/Core.h"

// Include GPIO Module API
#include "../GPIO/GPIO.h"

// Include Timing Module API
#include "../Timing/Timing.h"

// Include Serial Module API
#include "../Serial/Serial.h"

// Include Utilities Module API
#include "../Utilities/Utilities.h"

// Include the emulated RTC facade (DS3231 time source).
// The facade is injected by the runtime through RTCFacade::attach() before the
// sketch setup() runs, so the sketch can read the time in a board-like way.
#include "../RTC.h"

// Additional modules (HAL) will be included here as they are implemented.
