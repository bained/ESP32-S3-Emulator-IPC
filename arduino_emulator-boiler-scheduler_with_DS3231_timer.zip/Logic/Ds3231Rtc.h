#pragma once

#include "IClock.h"

namespace arduino {
namespace logic {

// DS3231 temperature-compensated RTC module driver (I2C, address 0x68).
//
// This class is PURE LOGIC: it owns the register level state (date/time,
// oscillator stop flag, aging offset) but performs no I2C transfer itself.
// The platform specific bus (Wire on the ESP32, a simulated bus in the
// emulator) is responsible for feeding readDeviceTime()/writeDeviceTime().
//
// Battery back-up note: the CR2032 on the DS3231 module keeps the time and the
// SQW/32kHz output running while the HLK-PM01 side is powered down, so the
// schedule survives mains interruptions (that is exactly why the RTC exists).
class Ds3231Rtc {
public:
    explicit Ds3231Rtc(IClock& bus);

    // Reads the RTC through the bus and caches the result. Returns false when
    // the bus is not available (the last valid time is kept).
    bool readNow();
    // Pushes the cached time into the RTC hardware.
    bool writeNow();
    // Clears the oscillator-stop flag after a power loss.
    bool clearLostPowerFlag();

    datetime::DateTime now() const { return m_cached; }
    bool lostPower() const { return m_lostPower; }
    float temperatureC() const { return m_temperatureC; }

    // Re-synchronises the local clock from a reference timestamp
    // (serial command on the ESP32, proxy command in the emulator).
    bool syncTo(const datetime::DateTime& reference);

    static constexpr uint8_t I2C_ADDRESS = 0x68;
    static constexpr int8_t SQW_1HZ_PIN = 15; // Optional 1 Hz interrupt wiring

private:
    IClock& m_bus;
    datetime::DateTime m_cached;
    bool m_lostPower;
    float m_temperatureC;
};

} // namespace logic
} // namespace arduino
