#pragma once

#include "../Core/DateTimeTypes.h"
#include <cstdint>

namespace arduino {
namespace logic {

// One daily heating window, e.g. "start at 06:30 for 60 minutes".
// A window regularly crosses midnight (23:15 + 60 min -> 00:15 next day).
struct BoilerWindow {
    bool enabled;
    uint32_t start;      // Seconds since local midnight (0 - 86399)
    uint32_t duration;   // Seconds (0 = window disabled in practice)

    // Absolute end, expressed as seconds since midnight of the start day.
    // Values above 86400 mean "spills over into the next day".
    uint32_t end() const { return start + duration; }
    bool crossesMidnight() const { return end() > 86400u; }
};

enum class BoilerPhase : uint8_t {
    IDLE = 0,     // Outside every window, element is off
    HEATING = 1,  // A window is active, the SSR requests power
    COOLDOWN = 2  // Window just ended, waiting for the end-of-cycle confirmation
};

// Boiler heating has huge thermal inertia, so the relay is allowed to stay on
// for a short "keep alive" period (default 60 s) past the nominal end of a
// window. This guarantees the requested amount of heat before the phase drops
// back to IDLE, without shortening any window.
enum class BoilerEvent : uint8_t {
    NONE = 0,
    WINDOW_STARTED,
    WINDOW_FINISHED,
    OVERRIDE_STARTED,
    OVERRIDE_CANCELLED,
    OVERRIDE_EXPIRED,
    SAFETY_LATCHED      // Continuous ON exceeded the software limit from config
};

// Decides whether the heating element has to be powered right now.
// Pure logic: no GPIO, no HAL, no Windows API. Time is passed in by the caller,
// which keeps the whole state machine deterministically unit testable.
class BoilerScheduler {
public:
    static constexpr size_t MAX_WINDOWS = 2;
    static constexpr int32_t MIN_TIMEZONE_OFFSET = -50400; // UTC-14:00
    static constexpr int32_t MAX_TIMEZONE_OFFSET = 50400;  // UTC+14:00

    BoilerScheduler();

    // --- Configuration -----------------------------------------------------
    // `start` and `duration` are clamped to sane ranges; a duration larger than
    // 24 hours is rejected (clamped) to guarantee a window never aliases itself.
    void setWindow(uint8_t index, bool enabled, uint32_t start, uint32_t duration);
    void setTimezoneOffset(int32_t offsetSeconds);
    void setSafetyLimit(uint32_t seconds); // 0 disables the continuous-ON guard
    void setCooldown(uint32_t seconds);

    const BoilerWindow& getWindow(uint8_t index) const { return m_windows[index]; }
    int32_t getTimezoneOffset() const { return m_tzOffset; }
    uint32_t getSafetyLimit() const { return m_safetyLimit; }
    uint32_t getCooldown() const { return m_cooldown; }

    // --- Manual override ---------------------------------------------------
    // Forces heating ON for `durationSeconds`, independent from the windows
    // (useful after a long shower or before a bath). Cancelled by the next
    // scheduled window start.
    void startOverride(uint32_t durationSeconds);
    void startOverrideUntil(int64_t epochSecond); // Restores a persisted override
    void cancelOverride();
    bool isOverrideActive() const { return m_overrideActive; }
    int64_t getOverrideUntilEpoch() const { return m_overrideUntil; }
    uint32_t getOverrideRemaining(int64_t epochSecond) const;

    // --- Evaluation --------------------------------------------------------
    // Feed the RTC time here (UTC). Returns the desired relay state.
    bool update(const datetime::DateTime& utcNow);

    bool isHeating() const { return m_phase == BoilerPhase::HEATING; }
    bool isSafetyLatched() const { return m_safetyLatched; }
    void clearSafetyLatch();

    BoilerPhase getPhase() const { return m_phase; }
    int8_t getActiveWindowIndex() const { return m_activeWindow; }
    uint32_t getContinuousOnSeconds() const { return m_continuousOn; }
    uint32_t getCurrentWindowElapsed(const datetime::DateTime& utcNow) const;

    // Seconds until the next scheduled window starts (0 when one is active).
    // Returns UINT32_MAX when no window is enabled at all.
    uint32_t secondsUntilNextStart(const datetime::DateTime& utcNow) const;

    // Human readable phase name for logging.
    const char* phaseName() const { return PHASE_NAMES[static_cast<uint8_t>(m_phase)]; }

    // Consume the pending event (returns NONE when nothing happened since the
    // previous call, so the application can log transitions exactly once).
    BoilerEvent consumeEvent();

    static constexpr const char* PHASE_NAMES[3] = {"IDLE", "HEATING", "COOLDOWN"};

private:
    BoilerWindow m_windows[MAX_WINDOWS];
    int32_t m_tzOffset;          // Local time = UTC + m_tzOffset
    uint32_t m_safetyLimit;      // 0 = disabled
    uint32_t m_cooldown;

    BoilerPhase m_phase;
    int8_t m_activeWindow;       // Index of the window driving HEATING, -1 for override
    bool m_overrideActive;
    int64_t m_overrideUntil;     // UTC epoch of override expiry
    uint32_t m_cooldownRemaining;

    bool m_safetyLatched;
    uint32_t m_continuousOn;

    int64_t m_lastEpoch;         // Epoch (UTC) of the previous update()
    bool m_initialized;

    BoilerEvent m_pendingEvent;

    // Per-window activity memory. Rising and falling edges of this flag are the
    // WINDOW_STARTED / WINDOW_FINISHED events; a flag left set across a
    // midnight rollover therefore still reports exactly one finish event.
    bool m_windowActive[MAX_WINDOWS];

    // True when `localSecond` lies inside the window (start inclusive, end exclusive).
    bool isInWindow(const BoilerWindow& window, uint32_t localSecond) const;

    void setEvent(BoilerEvent event);
    void enterPhase(BoilerPhase phase);
};

} // namespace logic
} // namespace arduino
