#pragma once

#include "../Core/Core.h"

namespace arduino {
namespace logic {

// SSR (solid state relay) driven heating element output.
//
// Hardware note: the Fotek-style "SSR-40DA" clone modules available on the
// market are usually **active LOW** (input pulled to GND = "on"), despite the
// silk screen. The polarity is therefore configurable (`ssr.active_low`) and
// the relay is always driven to the safe OFF level *before* any pin mode
// change, so a floating ESP pin can never switch the boiler on during boot.
class SSRRelay {
public:
    SSRRelay(uint8_t pin, bool activeLow = false);

    // Configures the pin output and forces the OFF state.
    void begin();

    // Requests the relay state (true = heating element powered).
    void set(bool on);
    bool isOn() const { return m_on; }

    void setActiveLow(bool activeLow) { m_activeLow = activeLow; }
    bool isActiveLow() const { return m_activeLow; }

    uint8_t getPin() const { return m_pin; }

    // Number of ON/OFF transitions since boot (diagnostics / wear estimate).
    uint32_t getSwitchingCount() const { return m_switches; }

private:
    uint8_t m_pin;
    bool m_activeLow;
    bool m_on;
    uint32_t m_switches;

    // Translates a logical state into the electrical level for this SSR.
    uint8_t levelFor(bool on) const;
};

} // namespace logic
} // namespace arduino
