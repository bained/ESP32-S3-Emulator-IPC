#include "SSRRelay.h"
#include "../GPIO/GPIO.h"

namespace arduino {
namespace logic {

SSRRelay::SSRRelay(uint8_t pin, bool activeLow)
    : m_pin(pin), m_activeLow(activeLow), m_on(false), m_switches(0) {}

uint8_t SSRRelay::levelFor(bool on) const {
    // Active LOW module: LOW level = relay closed = element powered.
    return (on == m_activeLow) ? LOW : HIGH;
}

void SSRRelay::begin() {
    m_on = false;
    // Write the safe level first, then enable the output driver. The emulator
    // stores the level, the ESP32 keeps the pin in a defined state from the
    // first microsecond after reset.
    digitalWrite(m_pin, levelFor(false));
    pinMode(m_pin, OUTPUT);
    digitalWrite(m_pin, levelFor(false));
}

void SSRRelay::set(bool on) {
    if (on == m_on) {
        return;
    }
    m_on = on;
    ++m_switches;
    digitalWrite(m_pin, levelFor(on));
}

} // namespace logic
} // namespace arduino
