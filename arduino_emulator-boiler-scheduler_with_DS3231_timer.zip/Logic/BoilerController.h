#pragma once

#include "../Core/DateTimeTypes.h"
#include "../HAL/IStorage.h"
#include "BoilerScheduler.h"
#include "Ds3231Rtc.h"
#include "IClock.h"
#include "SSRRelay.h"

#include <string>

namespace arduino {
namespace logic {

// Persisted configuration of the 24 h boiler schedule.
struct BoilerConfig {
    // Window 0 = daytime boost (e.g. 06:30 for 60 min)
    // Window 1 = night boost   (e.g. 22:00 for 30 min, may cross midnight)
    bool windowEnabled[BoilerScheduler::MAX_WINDOWS];
    uint32_t windowStart[BoilerScheduler::MAX_WINDOWS];    // seconds of day
    uint32_t windowDuration[BoilerScheduler::MAX_WINDOWS]; // seconds

    int32_t timezoneOffset;   // seconds, local = UTC + offset
    uint32_t cooldownSeconds; // thermal keep-alive after a window
    uint32_t safetyLimit;     // 0 disables the continuous-ON guard
    bool ssrActiveLow;
    uint8_t ssrPin;
    uint32_t reportInterval;  // serial status report period (ms)
    bool quietAtNight;        // detailed logs only inside the windows
    bool overrideActive;      // persisted manual override
    int64_t overrideUntil;    // UTC epoch of the override expiry

    BoilerConfig();
};

// Orchestrates clock -> scheduler -> SSR relay and keeps the config file in
// sync. Contains no GPIO or HAL calls itself: it only talks to abstractions,
// which makes it reusable on the ESP32 target as-is.
class BoilerController {
public:
    BoilerController(BoilerScheduler& scheduler, Ds3231Rtc& rtc, SSRRelay& relay,
                     hal::IStorage& storage);

    // Parses the configuration, applies it and restores the persisted override.
    // Missing or invalid values fall back to defaults and are written back, so
    // the file always ends up complete and self documenting.
    bool begin();

    // Single non-blocking control step. Returns true when the relay is ON.
    bool update();

    // Returns true when the stored configuration changed on disk and had to be
    // reloaded (the caller can log this).
    bool reloadConfig();

    // Buttons / serial commands.
    void requestBoost(uint32_t minutes);
    void cancelBoost();
    void clearFault();

    // Fault string (empty when healthy).
    const std::string& fault() const { return m_fault; }

    BoilerConfig& config() { return m_config; }
    const BoilerConfig& config() const { return m_config; }

    // Default config file content (used by main.cpp to bootstrap the file).
    static const char* defaultFileName();

private:
    BoilerScheduler& m_scheduler;
    Ds3231Rtc& m_rtc;
    SSRRelay& m_relay;
    hal::IStorage& m_storage;

    BoilerConfig m_config;
    std::string m_fault;
    datetime::DateTime m_lastRtcRead;
    bool m_haveRtcTime;

    // --- Config helpers ---
    void readConfig();
    void applyConfig();
    void persistRuntimeState();
    void ensureDefaults();

    // Value parsers (strict, they keep the previous value on failure).
    bool readBool(hal::IStorage& storage, const std::string& key, bool& value);
    bool readInt(hal::IStorage& storage, const std::string& key, long& value);
    bool readClock(hal::IStorage& storage, const std::string& key, uint32_t& secondsOfDay);
    bool readDuration(hal::IStorage& storage, const std::string& key, uint32_t& seconds);

    // Logs the scheduler event (if any) through the standard Serial API.
    void reportEvent();
};

} // namespace logic
} // namespace arduino
