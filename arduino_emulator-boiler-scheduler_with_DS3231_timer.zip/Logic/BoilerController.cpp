#include "BoilerController.h"
#include "../Serial/Serial.h"

#include <algorithm>
#include <cstdio>
#include <iterator>

namespace arduino {
namespace logic {

namespace {

constexpr uint32_t SECONDS_PER_DAY = 86400u;

// Config keys: "<section>.<key>" as addressed by hal::IStorage.
constexpr const char* KEY_W1_ENABLED = "window1.enabled";
constexpr const char* KEY_W1_START = "window1.start";
constexpr const char* KEY_W1_DURATION = "window1.duration_min";
constexpr const char* KEY_W2_ENABLED = "window2.enabled";
constexpr const char* KEY_W2_START = "window2.start";
constexpr const char* KEY_W2_DURATION = "window2.duration_min";
constexpr const char* KEY_TIMEZONE = "time.timezone_min";
constexpr const char* KEY_COOLDOWN = "control.cooldown_sec";
constexpr const char* KEY_SAFETY = "control.safety_limit_min";
constexpr const char* KEY_SSR_POLARITY = "ssr.active_low";
constexpr const char* KEY_SSR_PIN = "ssr.pin";
constexpr const char* KEY_REPORT = "system.report_interval_ms";
constexpr const char* KEY_QUIET = "system.quiet_at_night";
constexpr const char* KEY_OVR_ACTIVE = "override.active";
constexpr const char* KEY_OVR_UNTIL = "override.until";

// Hard limits (defensive: a corrupted file must never produce a 24 h heater).
constexpr uint32_t MIN_WINDOW_SECONDS = 5u * 60u;
constexpr uint32_t MAX_WINDOW_SECONDS = 6u * 3600u;
constexpr uint32_t MAX_COOLDOWN_SECONDS = 3600u;
constexpr uint32_t MAX_SAFETY_SECONDS = 12u * 3600u;

} // namespace

// ==========================================
// BoilerConfig
// ==========================================

BoilerConfig::BoilerConfig()
    : timezoneOffset(3 * 3600), // Europe/Sofia (EET), DST is not modelled
      cooldownSeconds(60),
      safetyLimit(2u * 3600u),
      ssrActiveLow(false),
      ssrPin(5),                // WeMos D1 mini PRO: D1 / GPIO5
      reportInterval(10000),
      quietAtNight(true),
      overrideActive(false),
      overrideUntil(0) {
    // Defaults fulfil the requested daily pattern:
    //   06:30 - 07:30 (60 min) daytime boost, 22:00 - 22:30 (30 min) night boost.
    windowEnabled[0] = true;
    windowStart[0] = 6u * 3600u + 30u * 60u;
    windowDuration[0] = 60u * 60u;

    windowEnabled[1] = true;
    windowStart[1] = 22u * 3600u;
    windowDuration[1] = 30u * 60u;
}

const char* BoilerController::defaultFileName() {
    return "config/boiler.ini";
}

// ==========================================
// Construction
// ==========================================

BoilerController::BoilerController(BoilerScheduler& scheduler, Ds3231Rtc& rtc, SSRRelay& relay,
                                   hal::IStorage& storage)
    : m_scheduler(scheduler),
      m_rtc(rtc),
      m_relay(relay),
      m_storage(storage),
      m_config(),
      m_fault(),
      m_lastRtcRead{2026, 1, 1, 0, 0, 0},
      m_haveRtcTime(false) {}

// ==========================================
// Config readers
// ==========================================

bool BoilerController::readBool(hal::IStorage& storage, const std::string& key, bool& value) {
    bool parsed = false;
    if (!storage.getBool(key, parsed)) {
        return false;
    }
    value = parsed;
    return true;
}

bool BoilerController::readInt(hal::IStorage& storage, const std::string& key, long& value) {
    long parsed = 0;
    if (!storage.getInt(key, parsed)) {
        return false;
    }
    value = parsed;
    return true;
}

bool BoilerController::readClock(hal::IStorage& storage, const std::string& key,
                                 uint32_t& secondsOfDay) {
    std::string text;
    if (!storage.getString(key, text)) {
        return false;
    }
    return datetime::parseClock(text, secondsOfDay);
}

bool BoilerController::readDuration(hal::IStorage& storage, const std::string& key,
                                    uint32_t& seconds) {
    long minutes = 0;
    if (!readInt(storage, key, minutes)) {
        return false;
    }
    if (minutes < 0) {
        return false;
    }
    seconds = static_cast<uint32_t>(minutes) * 60u;
    return true;
}


// ==========================================
// Configuration lifecycle
// ==========================================

void BoilerController::readConfig() {
    BoilerConfig cfg; // Start from defaults: any unreadable key keeps its default
    long value = 0;

    // --- Window 1 (daytime boost) ---
    readBool(m_storage, KEY_W1_ENABLED, cfg.windowEnabled[0]);
    readClock(m_storage, KEY_W1_START, cfg.windowStart[0]);
    readDuration(m_storage, KEY_W1_DURATION, cfg.windowDuration[0]);

    // --- Window 2 (night boost) ---
    readBool(m_storage, KEY_W2_ENABLED, cfg.windowEnabled[1]);
    readClock(m_storage, KEY_W2_START, cfg.windowStart[1]);
    readDuration(m_storage, KEY_W2_DURATION, cfg.windowDuration[1]);

    // --- Clock / control ---
    if (readInt(m_storage, KEY_TIMEZONE, value) && value >= -14 * 60 && value <= 14 * 60) {
        cfg.timezoneOffset = static_cast<int32_t>(value) * 60;
    }
    if (readInt(m_storage, KEY_COOLDOWN, value) && value >= 0 &&
        value <= static_cast<long>(MAX_COOLDOWN_SECONDS)) {
        cfg.cooldownSeconds = static_cast<uint32_t>(value);
    }
    if (readInt(m_storage, KEY_SAFETY, value) && value >= 0 &&
        value * 60 <= static_cast<long>(MAX_SAFETY_SECONDS)) {
        cfg.safetyLimit = static_cast<uint32_t>(value) * 60u;
    }

    // --- Actuator ---
    readBool(m_storage, KEY_SSR_POLARITY, cfg.ssrActiveLow);
    if (readInt(m_storage, KEY_SSR_PIN, value) && value >= 0 && value <= 44) {
        cfg.ssrPin = static_cast<uint8_t>(value);
    }

    // --- System ---
    if (readInt(m_storage, KEY_REPORT, value) && value >= 1000 && value <= 3600000) {
        cfg.reportInterval = static_cast<uint32_t>(value);
    }
    readBool(m_storage, KEY_QUIET, cfg.quietAtNight);

    // --- Persisted manual override ---
    std::string untilText;
    if (readBool(m_storage, KEY_OVR_ACTIVE, cfg.overrideActive) &&
        m_storage.getString(KEY_OVR_UNTIL, untilText)) {
        datetime::DateTime until{2026, 1, 1, 0, 0, 0};
        if (cfg.overrideActive && datetime::parseTimestamp(untilText, until)) {
            cfg.overrideUntil = datetime::toEpoch(until);
        } else {
            cfg.overrideActive = false;
            cfg.overrideUntil = 0;
        }
    } else {
        cfg.overrideActive = false;
        cfg.overrideUntil = 0;
    }

    // --- Range clamping for the heating windows (physical safety) ---
    for (size_t i = 0; i < BoilerScheduler::MAX_WINDOWS; ++i) {
        cfg.windowStart[i] = std::min(cfg.windowStart[i], SECONDS_PER_DAY - 1u);
        cfg.windowDuration[i] =
            std::max(MIN_WINDOW_SECONDS, std::min(MAX_WINDOW_SECONDS, cfg.windowDuration[i]));
    }

    m_config = cfg;
}

void BoilerController::applyConfig() {
    m_scheduler.setTimezoneOffset(m_config.timezoneOffset);
    m_scheduler.setCooldown(m_config.cooldownSeconds);
    m_scheduler.setSafetyLimit(m_config.safetyLimit);

    for (uint8_t i = 0; i < BoilerScheduler::MAX_WINDOWS; ++i) {
        m_scheduler.setWindow(i, m_config.windowEnabled[i], m_config.windowStart[i],
                              m_config.windowDuration[i]);
    }

    m_relay.setActiveLow(m_config.ssrActiveLow);

    if (m_config.overrideActive) {
        m_scheduler.startOverrideUntil(m_config.overrideUntil);
    } else {
        m_scheduler.cancelOverride();
    }
}

// ==========================================
// Boot sequence
// ==========================================

void BoilerController::ensureDefaults() {
    // Persist the effective values so the file is always complete and self
    // documenting (a hand edited file keeps its values, missing keys are filled).
    bool dirty = false;
    auto putBool = [&](const char* key, bool value) {
        bool current = false;
        if (!m_storage.getBool(key, current) || current != value) {
            m_storage.setBool(key, value);
            dirty = true;
        }
    };
    auto putInt = [&](const char* key, long value) {
        long current = 0;
        if (!m_storage.getInt(key, current) || current != value) {
            m_storage.setInt(key, value);
            dirty = true;
        }
    };
    auto putText = [&](const char* key, const std::string& value) {
        std::string current;
        if (!m_storage.getString(key, current) || current != value) {
            m_storage.setString(key, value);
            dirty = true;
        }
    };

    putBool(KEY_W1_ENABLED, m_config.windowEnabled[0]);
    putText(KEY_W1_START, datetime::formatHHMM(m_config.windowStart[0]));
    putInt(KEY_W1_DURATION, static_cast<long>(m_config.windowDuration[0] / 60u));

    putBool(KEY_W2_ENABLED, m_config.windowEnabled[1]);
    putText(KEY_W2_START, datetime::formatHHMM(m_config.windowStart[1]));
    putInt(KEY_W2_DURATION, static_cast<long>(m_config.windowDuration[1] / 60u));

    putInt(KEY_TIMEZONE, m_config.timezoneOffset / 60);
    putInt(KEY_COOLDOWN, static_cast<long>(m_config.cooldownSeconds));
    putInt(KEY_SAFETY, static_cast<long>(m_config.safetyLimit / 60u));

    putBool(KEY_SSR_POLARITY, m_config.ssrActiveLow);
    putInt(KEY_SSR_PIN, m_config.ssrPin);
    putInt(KEY_REPORT, static_cast<long>(m_config.reportInterval));
    putBool(KEY_QUIET, m_config.quietAtNight);

    // The override section is always materialised so the file stays complete.
    putBool(KEY_OVR_ACTIVE, m_scheduler.isOverrideActive());
    if (m_scheduler.isOverrideActive()) {
        putText(KEY_OVR_UNTIL, datetime::format(datetime::fromEpoch(
                                   m_scheduler.getOverrideUntilEpoch())));
    }

    if (dirty) {
        m_storage.commit();
    }
}

bool BoilerController::begin() {
    m_fault.clear();
    m_haveRtcTime = false;

    // 1. Safe actuator state first, before anything else can happen.
    m_relay.begin();

    // 2. Configuration file (auto-created with defaults when missing).
    m_storage.reload();
    readConfig();
    ensureDefaults();

    // 3. Apply to the scheduler.
    applyConfig();

    // 4. Clock.
    if (!m_rtc.readNow()) {
        m_fault = "RTC not responding";
        return false;
    }
    m_lastRtcRead = m_rtc.now();
    m_haveRtcTime = true;

    if (m_rtc.lostPower()) {
        m_rtc.clearLostPowerFlag();
        Serial.println("[RTC] Warning: oscillator stop flag was set (battery/power loss).");
        Serial.println("[RTC] Time may be wrong until it is synchronised from the serial port.");
    }

    // 5. Evaluate the schedule for the very first time.
    const bool on = m_scheduler.update(m_lastRtcRead);
    m_relay.set(on);

    return true;
}
// ==========================================
// Runtime
// ==========================================

bool BoilerController::update() {
    if (!m_rtc.readNow()) {
        // Fail safe: no valid time means no heating.
        m_relay.set(false);
        m_fault = "RTC not responding";
        return false;
    }
    m_fault.clear();
    m_lastRtcRead = m_rtc.now();
    m_haveRtcTime = true;

    const bool on = m_scheduler.update(m_lastRtcRead);
    m_relay.set(on);

    reportEvent();
    return m_relay.isOn();
}

bool BoilerController::reloadConfig() {
    if (!m_storage.reload()) {
        return false;
    }
    // Remember the currently effective values to detect a real change.
    const BoilerConfig previous = m_config;
    readConfig();

    bool changed = false;
    for (size_t i = 0; i < BoilerScheduler::MAX_WINDOWS; ++i) {
        changed |= (previous.windowEnabled[i] != m_config.windowEnabled[i]);
        changed |= (previous.windowStart[i] != m_config.windowStart[i]);
        changed |= (previous.windowDuration[i] != m_config.windowDuration[i]);
    }
    changed |= (previous.timezoneOffset != m_config.timezoneOffset);
    changed |= (previous.cooldownSeconds != m_config.cooldownSeconds);
    changed |= (previous.safetyLimit != m_config.safetyLimit);
    changed |= (previous.ssrActiveLow != m_config.ssrActiveLow);
    changed |= (previous.reportInterval != m_config.reportInterval);
    changed |= (previous.quietAtNight != m_config.quietAtNight);

    if (!changed) {
        return false;
    }

    // The relay polarity must be re-applied through begin() so the new level is
    // written before the pin is re-enabled, then the schedule is re-evaluated.
    if (previous.ssrActiveLow != m_config.ssrActiveLow) {
        m_relay.begin();
    }
    applyConfig();
    ensureDefaults();
    m_scheduler.update(m_lastRtcRead);
    return true;
}

void BoilerController::persistRuntimeState() {
    m_storage.setBool(KEY_OVR_ACTIVE, m_scheduler.isOverrideActive());
    if (m_scheduler.isOverrideActive()) {
        const datetime::DateTime until =
            datetime::fromEpoch(m_scheduler.getOverrideUntilEpoch());
        m_storage.setString(KEY_OVR_UNTIL, datetime::format(until));
    } else {
        m_storage.remove(KEY_OVR_UNTIL);
    }
    m_storage.commit();
    m_config.overrideActive = m_scheduler.isOverrideActive();
    m_config.overrideUntil = m_scheduler.getOverrideUntilEpoch();
}

void BoilerController::requestBoost(uint32_t minutes) {
    if (minutes == 0 || minutes > 180) {
        minutes = 60; // Sensible default when the command carries no argument
    }
    if (m_scheduler.isSafetyLatched()) {
        Serial.println("[Boost] Refused: safety latch is active. Clear it first ('C').");
        return;
    }
    m_scheduler.startOverride(minutes * 60u);
    persistRuntimeState();
    Serial.printf("[Boost] Manual heating for %lu min.\n", static_cast<unsigned long>(minutes));
    m_scheduler.update(m_lastRtcRead);
}

void BoilerController::cancelBoost() {
    m_scheduler.cancelOverride();
    persistRuntimeState();
    Serial.println("[Boost] Manual heating cancelled.");
    m_scheduler.update(m_lastRtcRead);
}

void BoilerController::clearFault() {
    m_scheduler.clearSafetyLatch();
    m_fault.clear();
    m_relay.set(false);
    m_scheduler.update(m_lastRtcRead);
    Serial.println("[Safety] Fault cleared, schedule re-evaluated.");
}

// ==========================================
// Event reporting
// ==========================================

void BoilerController::reportEvent() {
    const datetime::DateTime now = m_lastRtcRead;
    const datetime::DateTime local = datetime::fromEpoch(datetime::toEpoch(now) +
                                                        m_config.timezoneOffset);

    switch (m_scheduler.consumeEvent()) {
    case BoilerEvent::WINDOW_STARTED: {
        // Identify which window just started and report its local end time
        // (a window may legitimately end after midnight).
        const uint32_t localSecond = datetime::secondOfDay(local);
        for (uint8_t i = 0; i < BoilerScheduler::MAX_WINDOWS; ++i) {
            const BoilerWindow& w = m_scheduler.getWindow(i);
            if (!w.enabled || w.duration == 0) {
                continue;
            }
            // The window may have started today or (spill-over) yesterday.
            for (int32_t dayOffset : {-1, 0}) {
                const int64_t startOffset =
                    static_cast<int64_t>(dayOffset) * 86400 + static_cast<int64_t>(w.start);
                const int64_t secondsOfDay = static_cast<int64_t>(localSecond) - startOffset;
                if (secondsOfDay >= 0 && secondsOfDay < static_cast<int64_t>(w.duration)) {
                    const uint32_t endSecond = (w.start + w.duration) % 86400u;
                    Serial.printf("[Schedule] Window %u STARTED at %s (duration %lu min, ends %s)\n",
                                  static_cast<unsigned>(i + 1),
                                  datetime::formatHHMM(w.start).c_str(),
                                  static_cast<unsigned long>(w.duration / 60u),
                                  datetime::formatHHMM(endSecond).c_str());
                    return;
                }
            }
        }
        break;
    }
    case BoilerEvent::WINDOW_FINISHED:
        Serial.printf("[Schedule] Window finished at %s - relay off after %lu s keep-alive\n",
                      datetime::format(local).c_str(),
                      static_cast<unsigned long>(m_config.cooldownSeconds));
        break;
    case BoilerEvent::OVERRIDE_STARTED:
        Serial.printf("[Schedule] Manual boost active until %s\n",
                      datetime::format(datetime::fromEpoch(m_scheduler.getOverrideUntilEpoch() +
                                                           m_config.timezoneOffset)).c_str());
        break;
    case BoilerEvent::OVERRIDE_CANCELLED:
        Serial.println("[Schedule] Manual boost cancelled.");
        break;
    case BoilerEvent::OVERRIDE_EXPIRED:
        Serial.println("[Schedule] Manual boost expired.");
        break;
    case BoilerEvent::SAFETY_LATCHED:
        Serial.printf("[Safety] Continuous ON exceeded %lu min -> relay latched OFF.\n",
                      static_cast<unsigned long>(m_config.safetyLimit / 60u));
        break;
    case BoilerEvent::NONE:
    default:
        break;
    }
}

} // namespace logic
} // namespace arduino




