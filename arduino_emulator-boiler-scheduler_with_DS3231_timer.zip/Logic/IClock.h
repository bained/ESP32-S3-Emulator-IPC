#pragma once

#include "../Core/DateTimeTypes.h"

namespace arduino {
namespace logic {

// Hardware independent real-time clock abstraction.
// The Logic layer never talks to the DS3231 (or to Windows) directly: it only
// sees this interface, so the very same scheduler code runs on the emulator and
// on the physical Wemos D1 mini PRO + DS3231 build.
class IClock {
public:
    virtual ~IClock() = default;

    // Current local date/time.
    virtual datetime::DateTime now() = 0;

    // True when the clock lost track of time (DS3231 OSF bit / power loss).
    virtual bool lostPower() const = 0;

    // Writes the clock (DS3231 register write on hardware).
    virtual bool setDateTime(const datetime::DateTime& dt) = 0;

    // Short diagnostic name of the time source, e.g. "DS3231" or "Simulated".
    virtual const char* sourceName() const = 0;
};

} // namespace logic
} // namespace arduino
