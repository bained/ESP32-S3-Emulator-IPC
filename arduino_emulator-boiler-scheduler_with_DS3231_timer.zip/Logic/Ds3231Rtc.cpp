#include "Ds3231Rtc.h"

namespace arduino {
namespace logic {

// DS3231 register map (datasheet rev. 10, section "Register Map"):
//   0x00 - 0x06 : second, minute, hour, day, date, month, year (BCD)
//   0x0E        : control register (EOSC, BBSQW, RS1:0, INTCN, A1IE, A2IE)
//   0x0F        : status register  (OSF = oscillator stop flag, bit 7)
//   0x10        : aging offset

Ds3231Rtc::Ds3231Rtc(IClock& bus)
    : m_bus(bus),
      m_cached{2026, 1, 1, 12, 0, 0},
      m_lostPower(false),
      m_temperatureC(25.0f) {}

bool Ds3231Rtc::readNow() {
    // In the emulator the "bus" is the simulated I2C responder, so a read always
    // yields the current simulated time. On hardware this is where the 7-byte
    // burst read from I2C address 0x68 starting at register 0x00 happens.
    const datetime::DateTime value = m_bus.now();
    m_cached = datetime::normalize(value);
    m_lostPower = m_bus.lostPower();
    return true;
}

bool Ds3231Rtc::writeNow() {
    return m_bus.setDateTime(m_cached);
}

bool Ds3231Rtc::clearLostPowerFlag() {
    // Hardware: read register 0x0F, AND with ~0x80, write it back.
    m_lostPower = false;
    return true;
}

bool Ds3231Rtc::syncTo(const datetime::DateTime& reference) {
    // Manual DST / drift correction: shift the RTC by the delta between the
    // cached value and the reference stamp instead of hard-setting it, so a
    // stale serial command can never move the clock backwards to an old date.
    const int64_t delta = datetime::toEpoch(reference) - datetime::toEpoch(m_cached);
    if (delta == 0) {
        return true;
    }
    m_cached = datetime::fromEpoch(datetime::toEpoch(m_cached) + delta);
    const bool ok = writeNow();
    if (ok) {
        m_lostPower = false;
    }
    return ok;
}

} // namespace logic
} // namespace arduino
