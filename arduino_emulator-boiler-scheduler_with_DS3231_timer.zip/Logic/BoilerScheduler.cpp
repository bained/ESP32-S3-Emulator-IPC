#include "BoilerScheduler.h"

#include <algorithm>
#include <limits>

namespace arduino {
namespace logic {

namespace {
constexpr uint32_t SECONDS_PER_DAY = 86400u;
constexpr uint32_t MAX_OVERRIDE_SECONDS = 6u * 3600u; // 6 h is plenty for a manual boost
} // namespace

BoilerScheduler::BoilerScheduler()
    : m_tzOffset(0),
      m_safetyLimit(2u * 3600u),
      m_cooldown(60u),
      m_phase(BoilerPhase::IDLE),
      m_activeWindow(-1),
      m_overrideActive(false),
      m_overrideUntil(0),
      m_cooldownRemaining(0),
      m_safetyLatched(false),
      m_continuousOn(0),
      m_lastEpoch(0),
      m_initialized(false),
      m_pendingEvent(BoilerEvent::NONE) {
    for (size_t i = 0; i < MAX_WINDOWS; ++i) {
        m_windows[i] = BoilerWindow{false, 0, 0};
        m_windowActive[i] = false;
    }
}

void BoilerScheduler::setWindow(uint8_t index, bool enabled, uint32_t start, uint32_t duration) {
    if (index >= MAX_WINDOWS) {
        return;
    }
    // Clamp to a valid day and forbid >= 24 h so a window can never alias itself.
    const uint32_t clampedStart = std::min(start, SECONDS_PER_DAY - 1u);
    const uint32_t clampedDuration = std::min(duration, SECONDS_PER_DAY - 1u);

    m_windows[index].enabled = enabled && (clampedDuration > 0u);
    m_windows[index].start = clampedStart;
    m_windows[index].duration = clampedDuration;
    m_windowActive[index] = false;
}

void BoilerScheduler::setTimezoneOffset(int32_t offsetSeconds) {
    m_tzOffset = std::max(MIN_TIMEZONE_OFFSET, std::min(MAX_TIMEZONE_OFFSET, offsetSeconds));
}

void BoilerScheduler::setSafetyLimit(uint32_t seconds) {
    m_safetyLimit = seconds;
}

void BoilerScheduler::setCooldown(uint32_t seconds) {
    m_cooldown = std::min(seconds, 3600u);
}

void BoilerScheduler::setEvent(BoilerEvent event) {
    // A latched safety fault and a real transition are both important, keep the
    // first event until the application consumes it.
    if (m_pendingEvent == BoilerEvent::NONE) {
        m_pendingEvent = event;
    }
}

BoilerEvent BoilerScheduler::consumeEvent() {
    const BoilerEvent event = m_pendingEvent;
    m_pendingEvent = BoilerEvent::NONE;
    return event;
}

void BoilerScheduler::enterPhase(BoilerPhase phase) {
    m_phase = phase;
}

void BoilerScheduler::clearSafetyLatch() {
    m_safetyLatched = false;
    m_continuousOn = 0;
    m_phase = BoilerPhase::IDLE;
    m_activeWindow = -1;
}


// ==========================================
// Manual override
// ==========================================

void BoilerScheduler::startOverride(uint32_t durationSeconds) {
    const uint32_t seconds = std::max(1u, std::min(durationSeconds, MAX_OVERRIDE_SECONDS));
    // The deadline is absolute, exactly like the value persisted in the config
    // file, so an override survives a reboot of the emitter.
    const int64_t base = m_initialized ? m_lastEpoch : 0;
    startOverrideUntil(base + static_cast<int64_t>(seconds));
}

void BoilerScheduler::startOverrideUntil(int64_t epochSecond) {
    m_overrideActive = true;
    m_overrideUntil = epochSecond;
    setEvent(BoilerEvent::OVERRIDE_STARTED);
}

void BoilerScheduler::cancelOverride() {
    if (m_overrideActive) {
        m_overrideActive = false;
        m_overrideUntil = 0;
        setEvent(BoilerEvent::OVERRIDE_CANCELLED);
    }
}

uint32_t BoilerScheduler::getOverrideRemaining(int64_t epochSecond) const {
    if (!m_overrideActive || m_overrideUntil <= epochSecond) {
        return 0;
    }
    const int64_t remaining = m_overrideUntil - epochSecond;
    return static_cast<uint32_t>(std::min<int64_t>(remaining, std::numeric_limits<uint32_t>::max()));
}

// ==========================================
// Window predicate
// ==========================================

bool BoilerScheduler::isInWindow(const BoilerWindow& window, uint32_t localSecond) const {
    if (!window.enabled || window.duration == 0u) {
        return false;
    }
    // Only the current day and the previous day can reach into "now"
    // (a window duration is always shorter than 24 h).
    for (int32_t dayOffset = -1; dayOffset <= 0; ++dayOffset) {
        const int64_t segmentStart = static_cast<int64_t>(dayOffset) * SECONDS_PER_DAY +
                                     static_cast<int64_t>(window.start);
        const int64_t segmentEnd = segmentStart + static_cast<int64_t>(window.duration);
        if (static_cast<int64_t>(localSecond) >= segmentStart &&
            static_cast<int64_t>(localSecond) < segmentEnd) {
            return true;
        }
    }
    return false;
}

// ==========================================
// Main state machine
// ==========================================

bool BoilerScheduler::update(const datetime::DateTime& utcNow) {
    const int64_t utcEpoch = datetime::toEpoch(datetime::normalize(utcNow));
    const int64_t localEpoch = utcEpoch + m_tzOffset;
    const uint32_t localSecond = static_cast<uint32_t>(
        ((localEpoch % SECONDS_PER_DAY) + SECONDS_PER_DAY) % SECONDS_PER_DAY);

    int64_t delta = 0;
    if (m_initialized) {
        delta = utcEpoch - m_lastEpoch;
        if (delta < 0 || delta > 3600) {
            // Clock set backwards or RTC jumped: treat as a fresh boot so a
            // negative elapsed time can never corrupt the counters.
            delta = 0;
            m_initialized = false;
        }
    }

    // --- Boot / re-sync: adopt the schedule state of the current moment ----
    // Adopting an already running window must not be reported as a start event,
    // otherwise every boot would log a bogus "window started".
    const bool adopting = !m_initialized;
    if (adopting) {
        for (size_t i = 0; i < MAX_WINDOWS; ++i) {
            m_windowActive[i] = isInWindow(m_windows[i], localSecond);
        }
        m_continuousOn = 0;
        if (!m_overrideActive) {
            m_safetyLatched = false;
        }
    }

    // --- Window edges ------------------------------------------------------
    bool anyWindowActive = false;
    int8_t activeWindowIndex = -1;
    for (size_t i = 0; i < MAX_WINDOWS; ++i) {
        const bool active = isInWindow(m_windows[i], localSecond);
        if (active && !m_windowActive[i]) {
            // A window that starts while the device is running always takes over
            // from a manual boost. A window that is merely *adopted* at boot must
            // not, otherwise a persisted boost would be lost on every reboot that
            // happens inside a window.
            if (!adopting) {
                setEvent(BoilerEvent::WINDOW_STARTED);
                cancelOverride();
            }
        } else if (!active && m_windowActive[i]) {
            setEvent(BoilerEvent::WINDOW_FINISHED);
        }
        m_windowActive[i] = active;
        if (active) {
            anyWindowActive = true;
            if (activeWindowIndex < 0) {
                activeWindowIndex = static_cast<int8_t>(i);
            }
        }
    }

    // --- Override expiry ---------------------------------------------------
    if (m_overrideActive && utcEpoch >= m_overrideUntil) {
        m_overrideActive = false;
        m_overrideUntil = 0;
        setEvent(BoilerEvent::OVERRIDE_EXPIRED);
    }

    const bool overrideHeating = m_overrideActive;
    bool wantHeat = !m_safetyLatched && (anyWindowActive || overrideHeating);

    // --- Safety guard: continuous ON longer than the configured limit ------
    if (wantHeat) {
        m_continuousOn += static_cast<uint32_t>(std::max<int64_t>(delta, 0));
        if (m_safetyLimit > 0u && m_continuousOn > m_safetyLimit) {
            m_safetyLatched = true;
            wantHeat = false;
            setEvent(BoilerEvent::SAFETY_LATCHED);
        }
    } else {
        m_continuousOn = 0;
    }

    // --- Phase transitions -------------------------------------------------
    if (wantHeat) {
        if (m_phase != BoilerPhase::HEATING) {
            enterPhase(BoilerPhase::HEATING);
        }
        m_activeWindow = overrideHeating ? -1 : activeWindowIndex;
        m_cooldownRemaining = 0;
    } else if (m_phase == BoilerPhase::HEATING) {
        // Request disappeared (window finished or cancelled): keep the element
        // on for the short thermal keep-alive period, then release the relay.
        if (m_cooldown > 0u && !m_safetyLatched) {
            enterPhase(BoilerPhase::COOLDOWN);
            m_cooldownRemaining = m_cooldown;
            wantHeat = true;
        } else {
            enterPhase(BoilerPhase::IDLE);
            m_activeWindow = -1;
            m_cooldownRemaining = 0;
        }
    } else if (m_phase == BoilerPhase::COOLDOWN) {
        const uint32_t elapsed = static_cast<uint32_t>(std::max<int64_t>(delta, 0));
        m_cooldownRemaining = (elapsed >= m_cooldownRemaining) ? 0u : m_cooldownRemaining - elapsed;
        if (m_cooldownRemaining > 0u) {
            wantHeat = true;
        } else {
            enterPhase(BoilerPhase::IDLE);
            m_activeWindow = -1;
        }
    }

    m_lastEpoch = utcEpoch;
    m_initialized = true;
    return wantHeat;
}

// ==========================================
// Introspection helpers
// ==========================================

uint32_t BoilerScheduler::secondsUntilNextStart(const datetime::DateTime& utcNow) const {
    bool anyEnabled = false;
    uint32_t best = std::numeric_limits<uint32_t>::max();
    const int64_t utcEpoch = datetime::toEpoch(datetime::normalize(utcNow));

    for (size_t i = 0; i < MAX_WINDOWS; ++i) {
        const BoilerWindow& window = m_windows[i];
        if (!window.enabled || window.duration == 0u) {
            continue;
        }
        anyEnabled = true;

        const datetime::DateTime localNow = datetime::fromEpoch(utcEpoch + m_tzOffset);
        // Midnight of "today" in UTC epoch seconds.
        const int64_t localMidnightEpoch =
            datetime::daysFromCivil(localNow.year, localNow.month, localNow.day) * SECONDS_PER_DAY;
        const int64_t startTodayEpoch = localMidnightEpoch + window.start - m_tzOffset;

        int64_t diff = startTodayEpoch - utcEpoch;
        if (diff < 0) {
            diff += static_cast<int64_t>(SECONDS_PER_DAY);
        }
        if (diff < static_cast<int64_t>(best)) {
            best = static_cast<uint32_t>(diff);
        }
    }

    return anyEnabled ? best : std::numeric_limits<uint32_t>::max();
}

uint32_t BoilerScheduler::getCurrentWindowElapsed(const datetime::DateTime& utcNow) const {
    if (m_activeWindow < 0 || static_cast<size_t>(m_activeWindow) >= MAX_WINDOWS) {
        return 0;
    }
    const BoilerWindow& window = m_windows[m_activeWindow];
    const int64_t localEpoch = datetime::toEpoch(datetime::normalize(utcNow)) + m_tzOffset;
    const int64_t localSecond = ((localEpoch % SECONDS_PER_DAY) + SECONDS_PER_DAY) % SECONDS_PER_DAY;

    int64_t elapsed = localSecond - static_cast<int64_t>(window.start);
    if (elapsed < 0) {
        elapsed += static_cast<int64_t>(SECONDS_PER_DAY); // Spill-over from yesterday
    }
    if (elapsed < 0 || elapsed > static_cast<int64_t>(window.duration)) {
        return 0;
    }
    return static_cast<uint32_t>(elapsed);
}

} // namespace logic
} // namespace arduino

