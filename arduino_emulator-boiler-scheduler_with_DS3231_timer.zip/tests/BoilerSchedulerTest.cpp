// ============================================================
// BoilerScheduler self test (standalone, no external framework).
// Build:  scripts\msvc.cmd cl /nologo /std:c++17 /EHsc /I. ^
//                 tests\BoilerSchedulerTest.cpp Logic\BoilerScheduler.cpp ^
//                 /Fe:tests\BoilerSchedulerTest.exe
// ============================================================
#include "../Logic/BoilerScheduler.h"

#include <cstdio>

using arduino::datetime::DateTime;
using arduino::datetime::toEpoch;
using arduino::datetime::fromEpoch;
using arduino::logic::BoilerPhase;
using arduino::logic::BoilerScheduler;

static int g_failures = 0;
static int g_checks = 0;

#define CHECK(cond, msg)                                                  \
    do {                                                                  \
        ++g_checks;                                                       \
        if (!(cond)) {                                                    \
            ++g_failures;                                                 \
            std::printf("  FAIL: %s  (%s:%d)\n", msg, __FILE__, __LINE__); \
        }                                                                 \
    } while (0)

// Local (UTC+3) helper: build a UTC timestamp from a local clock reading.
static const int32_t TZ = 3 * 3600;
static DateTime localAt(int day, int h, int m, int s = 0) {
    const int64_t localEpoch =
        arduino::datetime::daysFromCivil(2026, 1, 1 + day) * 86400 + h * 3600 + m * 60 + s;
    return fromEpoch(localEpoch - TZ);
}

// Steps the scheduler minute by minute, returns the number of ON minutes.
static int runMinutes(BoilerScheduler& s, DateTime& cursor, int minutes, bool& sawOn) {
    int onMinutes = 0;
    for (int i = 0; i < minutes; ++i) {
        if (s.update(cursor)) {
            ++onMinutes;
            sawOn = true;
        }
        cursor = fromEpoch(toEpoch(cursor) + 60);
    }
    return onMinutes;
}

static void testDaytimeWindow() {
    std::printf("[Test] daytime window 06:30 for 60 min\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setCooldown(60);
    s.setWindow(0, true, 6 * 3600 + 30 * 60, 3600);
    s.setWindow(1, false, 0, 0);

    DateTime cursor = localAt(1, 6, 25);
    CHECK(!s.update(cursor), "relay OFF 5 min before the window");

    // 06:26 .. 08:25 walked minute by minute: the 60 min window plus one
    // keep-alive minute must produce exactly 61 ON minutes.
    bool on = false;
    const int onMinutes = runMinutes(s, cursor, 120, on);
    CHECK(onMinutes == 61, "relay ON for the window plus one keep-alive minute");
    CHECK(s.getPhase() == BoilerPhase::IDLE, "phase returns to IDLE after the window");
}

static void testCrossMidnightWindow() {
    std::printf("[Test] night window 23:15 for 60 min (crosses midnight)\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setCooldown(0);
    s.setWindow(0, false, 0, 0);
    s.setWindow(1, true, 23 * 3600 + 15 * 60, 3600);

    DateTime cursor = localAt(2, 23, 10);
    bool on = false;
    s.update(cursor);
    // 23:11 .. 23:20 walked: 23:15,16,17,18,19 are inside -> 5 ON minutes.
    CHECK(runMinutes(s, cursor, 10, on) == 5, "heating starts at 23:15 (5 min covered)");
    // The remaining 55 minutes then run across midnight and end at 00:15.
    CHECK(runMinutes(s, cursor, 100, on) == 55, "heating continues past midnight until 00:15");
    CHECK(!s.isHeating(), "relay released at 00:15");
    CHECK(s.getPhase() == BoilerPhase::IDLE, "IDLE after the midnight crossing");
}

static void testDisabledWindow() {
    std::printf("[Test] disabled window never heats\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setWindow(0, false, 8 * 3600, 3600);

    DateTime cursor = localAt(3, 7, 55);
    bool on = false;
    CHECK(runMinutes(s, cursor, 120, on) == 0, "disabled window produces no heating");
    CHECK(s.secondsUntilNextStart(cursor) == 0xFFFFFFFFu, "no enabled window -> no next start");
}

static void testBoost() {
    std::printf("[Test] manual boost outside any window\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setCooldown(0);
    s.setSafetyLimit(0); // Guard disabled for this scenario
    s.setWindow(0, true, 6 * 3600 + 30 * 60, 3600);

    DateTime cursor = localAt(4, 15, 0);
    CHECK(!s.update(cursor), "idle at 15:00");

    s.startOverride(30 * 60);
    CHECK(s.update(cursor), "boost switches the relay ON");

    bool on = true;
    const int boosted = runMinutes(s, cursor, 60, on); // 15:01 .. 16:00
    CHECK(boosted == 30, "boost lasts exactly 30 minutes");
    CHECK(!s.isOverrideActive(), "override expires by itself");
    CHECK(!s.isHeating(), "relay OFF after the boost");
}

static void testSafetyLatch() {
    std::printf("[Test] safety limit latches the relay OFF\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setCooldown(0);
    s.setSafetyLimit(10 * 60);     // 10 minutes
    s.setWindow(0, true, 0, 3600); // One hour window starting at 00:00

    DateTime cursor = localAt(5, 0, 0);
    bool on = false;
    const int onMinutes = runMinutes(s, cursor, 20, on);
    CHECK(s.isSafetyLatched(), "safety latch engages after the limit");
    CHECK(onMinutes == 11, "relay ON for the limit, then latched OFF");

    s.clearSafetyLatch();
    // A manual reset restarts the guard; the window is still open, so heating
    // resumes until the limit is reached again (or the window ends).
    CHECK(s.update(cursor), "heating resumes after the manual reset");
    CHECK(!s.isSafetyLatched(), "latch cleared");

    bool dummy = false;
    CHECK(runMinutes(s, cursor, 15, dummy) == 10, "the guard re-arms and stops after 10 more min");
    CHECK(s.isSafetyLatched(), "latch engages again after the second limit");
}

static void testBackwardClock() {
    std::printf("[Test] clock set backwards does not corrupt the state\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setCooldown(0);
    s.setWindow(0, true, 6 * 3600 + 30 * 60, 3600);

    DateTime cursor = localAt(6, 6, 40);
    CHECK(s.update(cursor), "heating inside the window");

    cursor = localAt(6, 3, 0); // RTC corrected two hours into the past
    CHECK(!s.update(cursor), "relay released after the clock jumped backwards");

    cursor = localAt(6, 6, 31);
    CHECK(s.update(cursor), "heating re-acquired on the next loop inside the window");
}

static void testPersistedBoostThroughBoot() {
    std::printf("[Test] a persisted boost survives a reboot inside a window\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setCooldown(0);
    s.setSafetyLimit(0);
    s.setWindow(0, true, 6 * 3600 + 30 * 60, 3600); // 06:30 .. 07:30

    // Simulate a reboot at 15:00 (outside every window) with a boost restored
    // from the config file. Without the fix the boot would cancel the boost.
    DateTime boot = localAt(7, 15, 0);
    s.startOverrideUntil(toEpoch(boot) + 20 * 60);
    CHECK(s.update(boot), "relay ON right after the reboot");
    CHECK(s.isOverrideActive(), "the restored boost survives the boot");

    // Walk 25 minutes: the boost heats for 20 of them, nothing else is active.
    DateTime cursor = boot;
    bool dummy = false;
    CHECK(runMinutes(s, cursor, 25, dummy) == 20, "boost keeps heating 20 more minutes");
    CHECK(!s.isOverrideActive(), "boost expired");
    CHECK(!s.isHeating(), "relay OFF after the boost");
}

static void testBoostCancelledByWindowStart() {
    std::printf("[Test] a boost is cancelled when a scheduled window starts\n");
    BoilerScheduler s;
    s.setTimezoneOffset(TZ);
    s.setCooldown(0);
    s.setSafetyLimit(0);
    s.setWindow(0, true, 16 * 3600, 30 * 60); // 16:00 .. 16:30

    // Boot at 15:50 with a persisted boost running until 16:40.
    DateTime boot = localAt(8, 15, 50);
    s.startOverrideUntil(toEpoch(boot) + 50 * 60);
    CHECK(s.update(boot), "boost heats before the window");

    // The window starts at 16:00 and must take over: the boost is cancelled, but
    // the heating request stays on because of the window itself.
    DateTime cursor = boot;
    bool dummy = false;
    runMinutes(s, cursor, 15, dummy); // 15:51 .. 16:05
    CHECK(!s.isOverrideActive(), "the started window cancelled the boost");
    CHECK(s.isHeating(), "heating continues, now driven by the window");
}

int main() {
    std::printf("=== BoilerScheduler self test ===\n");
    testDaytimeWindow();
    testCrossMidnightWindow();
    testDisabledWindow();
    testBoost();
    testSafetyLatch();
    testBackwardClock();
    testPersistedBoostThroughBoot();
    testBoostCancelledByWindowStart();

    std::printf("--- %d checks, %d failure(s) ---\n", g_checks, g_failures);
    return g_failures == 0 ? 0 : 1;
}
