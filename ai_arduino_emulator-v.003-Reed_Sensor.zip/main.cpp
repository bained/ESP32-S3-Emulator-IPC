#include "include/Arduino.h"
#include "Runtime/Runtime.h"
#include "GPIO/GPIOManager.h"
#include "HAL/WindowsPipeSensor.h"
#include "Logic/ReedSwitch.h"

// Standard configuration
const int ledPin = LED_BUILTIN;
const int reedPin = 5; // Digital magnetic reed switch pin

// Instantiate our HAL sensor pipe client
static arduino::hal::WindowsPipeSensor pipeSensor("\\\\.\\pipe\\SensorPipe");

// Instantiate our Reed Switch magnetic sensor
static arduino::ReedSwitch reedSwitch(reedPin, &pipeSensor);

// ==========================================
// User Application Code (Standard Sketch)
// ==========================================

void setup() {
    // Initialize serial communication
    Serial.begin(115200);
    Serial.println("==========================================");
    Serial.println("   ESP32-S3 Windows Reed Switch Emulator  ");
    Serial.println("==========================================");

    // Initialize LED and reed switch pins
    pinMode(ledPin, OUTPUT);
    pinMode(reedPin, INPUT_PULLUP);

    // Link the named pipe IPC sensor to Pin 5
    arduino::GPIOManager::getInstance().registerExternalSensor(reedPin, &pipeSensor);

    Serial.printf("[Setup] Registered named pipe sensor to pin %d\n", reedPin);
    Serial.printf("[Setup] Initialized Reed Switch (INPUT_PULLUP active-low)\n");
}

void loop() {
    // 1. Perform Reed Switch magnetic sensing step (LOW means magnet is near/closed)
    bool isMagnetNear = reedSwitch.isClosed();
    if (isMagnetNear) {
        digitalWrite(ledPin, HIGH); // Turn LED on if magnet is detected
    } else {
        digitalWrite(ledPin, LOW);  // Turn LED off if magnet is removed
    }

    // 2. Log Magnetic Switch status via our emulated Serial console
    Serial.printf("[Reed Switch Status] Magnet: %-6s -> LED_BUILTIN: %s (pin %d -> %s)\n",
                  (isMagnetNear ? "NEAR" : "AWAY"),
                  (isMagnetNear ? "ON" : "OFF"),
                  ledPin,
                  (isMagnetNear ? "HIGH" : "LOW"));

    delay(1000); // 1-second ticks
}

// ==========================================
// Emulator Entry Point
// ==========================================

int main() {
    // Initialize and boot the emulator run loop
    arduino::Runtime emulatorRuntime;
    emulatorRuntime.run();

    return 0;
}
